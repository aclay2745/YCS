import { Component } from '@angular/core';
import {
  CompanyInfo,
  DataStorageService,
} from '../../storage/data-storage.service';
import { Observable } from 'rxjs';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-tab4',
  templateUrl: 'tab4.page.html',
  styleUrls: ['tab4.page.scss'],
})
export class Tab4Page {
  companyInfo: Observable<CompanyInfo>;
  companyInfoModel: CompanyInfo = new CompanyInfo();

  constructor(
    private datastore: DataStorageService,
    private toastController: ToastController
  ) {
    this.companyInfo = this.datastore.companyInfoStore;
    this.companyInfo.subscribe((info) => {
      this.companyInfoModel = info;
    });
  }

  saveCompanyInfo() {
    this.datastore.saveCompanyInfo(this.companyInfoModel);
    this.presentToast('Company Information has been saved');
  }

  async presentToast(msg: string) {
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000,
      position: 'middle',
    });
    toast.present();
  }
}
