import { Component, OnInit } from '@angular/core';
import { DrawingModel, IndexDBDrawingResult } from '../../storage/models';
import { Observable, of } from 'rxjs';
import { DrawingFileServicesService } from '../../components/sketch/drawing-file-services.service';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
})
export class Tab3Page implements OnInit {
  storedDrawings: Array<IndexDBDrawingResult>;

  nameEditModeActive: Observable<boolean> = of(false);

  constructor(private drawingFileServices: DrawingFileServicesService) {}

  ngOnInit(): void {
    this.drawingFileServices.storedDrawings.subscribe((data) => {
      this.storedDrawings = data;
    });
  }

  saveActiveDrawing() {
    this.drawingFileServices.saveActiveDrawing();
  }

  loadDrawing(drawing: DrawingModel) {
    this.drawingFileServices.loadDrawing(drawing);
  }

  deleteDrawing(drawingId: string) {
    this.drawingFileServices.presentDeleteConfirm(drawingId);
  }

  newDrawing() {
    this.drawingFileServices.presentNewDrawingConfirm();
  }

  toggleNamedEditMode(flag: boolean) {
    this.nameEditModeActive = of(flag);
  }

  refreshDrawingsList() {
    this.drawingFileServices.refreshDrawingsList();
  }

  presentToast(msg: string) {
    this.drawingFileServices.presentToast(msg);
  }

  updateCurrentDrawingName(name: string) {
    this.drawingFileServices.currentDrawingDisplayName.next(name);
  }
}
