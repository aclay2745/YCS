import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { IonTabs, ModalController } from '@ionic/angular';
import { ImageModalComponent } from '../../components/image-modal/image-modal.component';
import { SketchService } from '../../components/sketch/sketch.service';
import { IconEnums } from '../../components/sketch/enums';
import Mode = IconEnums.Mode;
import { EstimateService } from '../../services/estimate/estimate.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss'],
})
export class TabsPage implements OnInit, OnDestroy {
  @ViewChild('ycstabs', { static: true })
  tabs: IonTabs;

  modal;

  public currentSQFT: number;
  public isEstimateActive: BehaviorSubject<boolean>;

  constructor(
    private modalController: ModalController,
    private sketchService: SketchService,
    private estimateService: EstimateService
  ) {}

  // TODO: Fix undo / redo
  undoRedoActive = () => this.sketchService.currentMode === Mode.DRAW;

  ngOnInit(): void {
    this.sketchService.ycsTabs = this.tabs;
    this.isEstimateActive = this.estimateService.isEstimateActive;
  }

  ngOnDestroy(): void {}

  async openImageModal(event: MouseEvent) {
    this.modal = await this.modalController.create({
      component: ImageModalComponent,
      componentProps: { value: 0 },
    });

    return await this.modal.present();
  }

  undo() {
    this.sketchService.undoLastLine();
  }

  redo() {
    this.sketchService.redoLastLine();
  }

  recalc() {
    this.estimateService.calculateAll();
  }

  private _fakeAjax(callback) {
    setTimeout(() => {
      callback('response');
    }, 200);
  }
}
