import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ViewChild,
} from '@angular/core';
import { SketchService } from '../../components/sketch/sketch.service';
import { SketchComponent } from '../../components/sketch/sketch.component';
import { BehaviorSubject } from 'rxjs';
import { CameraService } from '../../services/camera/camera.service';
import { PopoverMenuComponent } from '../../components/popover-menu/popover-menu.component';
import {
  IonFab,
  IonFabList,
  ModalController,
  PopoverController,
} from '@ionic/angular';
import { IconEnums } from '../../components/sketch/enums';
import { EstimateService } from '../../services/estimate/estimate.service';
import {
  DrawingModel,
  IconImageModel,
  IndexDBDrawingResult,
} from '../../storage/models';
import { DataStorageService } from '../../storage/data-storage.service';
import * as _ from 'lodash';
import * as moment from 'moment';
import { DrawingFileServicesService } from '../../components/sketch/drawing-file-services.service';
import Mode = IconEnums.Mode;
import DamageIcon = IconEnums.DamageIcon;
import EquipmentIcon = IconEnums.EquipmentIcon;
import StructureIcon = IconEnums.StructureIcon;
import EnvironmentIcon = IconEnums.EnvironmentIcon;
import IssueIconDescription = IconEnums.ItemDescriptions;
import IssueIcon = IconEnums.DamageIcon;
import ItemDescriptions = IconEnums.ItemDescriptions;
import { GridZoomService } from '../../components/sketch/grid-zoom.service';
import * as SVG from 'svg.js';
import { YcsPdfService } from '../../services/ycs-pdf-service/ycs-pdf.service';
// import { ConsoleReporter } from 'jasmine';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
})
export class Tab1Page implements AfterViewInit {
  @ViewChild('sketchInstance', { static: true })
  public sketchInstance: SketchComponent;

  @ViewChild('fabChild', { static: true })
  public fabChild: IonFab;

  @ViewChild('sketchMenu', { static: true })
  public sketchMenuChild: IonFabList;

  @ViewChild('damageMenu', { static: true })
  public damageMenuChild: IonFabList;

  @ViewChild('equipmentMenu', { static: true })
  public equipmentMenuChild: IonFabList;

  @ViewChild('structureMenu', { static: true })
  public structureMenuChild: IonFabList;

  @ViewChild('zoomMenu', { static: true })
  public zoomMenuChild: IonFabList;

  @ViewChild('mainMenuSketchChip', { static: true })
  public mainMenuSketchChipChild: HTMLElement;

  public sketchInstanceLoaded = false;
  public mode = Mode;
  public damageIcon = DamageIcon;
  public equipmentIcon = EquipmentIcon;
  public structureIcon = StructureIcon;
  public environmentIcon = EnvironmentIcon;
  public issueIconDescription = ItemDescriptions;

  public fabIcon: BehaviorSubject<string> = new BehaviorSubject(
    'SUB_BRICK.svg'
  );

  public currentMenu = 'sketch';
  public storedDrawingCount = 0;
  private storedImages: Array<IconImageModel>;
  private imagesSubscription;
  private _printModal;

  constructor(
    private estimateService: EstimateService,
    private sketchService: SketchService,
    private cameraService: CameraService,
    public popoverController: PopoverController,
    private _modalController: ModalController,
    private changeDetector: ChangeDetectorRef,
    private datastore: DataStorageService,
    private drawingFileService: DrawingFileServicesService,
    private gridZoomService: GridZoomService,
    public pdfService: YcsPdfService
  ) {
    this.imagesSubscription = this.cameraService.imageStackObs.subscribe(
      (images) => {
        this.storedImages = images;
      }
    );

    this.drawingFileService.storedDrawings.subscribe((data) => {
      this.storedDrawingCount = data.length;
    });
  }

  ngAfterViewInit() {
    // Initialize using the last drawing that was edited!
    this.datastore.getAllDrawings((drawings) => {
      if (drawings !== undefined) {
        if (drawings.length > 0) {
          const drawingsArray = [];
          drawings.forEach((d: IndexDBDrawingResult) => {
            drawingsArray.push(d.v);
          });

          const sorted: Array<DrawingModel> = _.orderBy(
            drawingsArray,
            (d: DrawingModel) =>
              moment(d.lastModified).format('DD-MM-YYYY HH:mm:ss')
          ).reverse();

          const drawingToLoad: DrawingModel = {
            drawingId: sorted[0].drawingId,
            lastModified: sorted[0].lastModified,
            display: sorted[0].display,
            lineArray: sorted[0].lineArray,
            svgDocument: {
              plotsRoot: sorted[0].svgDocument.plotsRoot,
              iconRoot: sorted[0].svgDocument.iconRoot,
            },
            // printAreaRect: sorted[0].printAreaRect
          };

          this.drawingFileService.loadDrawing(drawingToLoad);
          // this.printDataService.loadPrintArea(drawingToLoad.printAreaRect);
        }
      }
    });

    if (this.sketchInstance !== undefined && !this.sketchInstanceLoaded) {
      this.sketchService.setSketchComponentInstance(this.sketchInstance);
      this.sketchInstanceLoaded = true;
    }

    this.initSubstrateAndLineMenu();
  }

  resetPrintView() {
    SVG('plots').viewbox(0, 0, 1100, 800);
    SVG('icons').viewbox(0, 0, 1100, 800);
    SVG('grid').viewbox(0, 0, 1100, 800);
  }

  async showMenu() {
    const popover = await this.popoverController.create({
      component: PopoverMenuComponent,
      event: null,
      animated: true,
      showBackdrop: true,
    });
    return await popover.present();
  }

  initSubstrateAndLineMenu() {
    this.setDisplayInfo(this.issueIconDescription.SUB_BRICK);
    this.sketchService.setSubstrate('SUB_BRICK', 18);
  }

  setMode(mode: Mode, e) {
    e.stopPropagation();
    this.sketchService.setMode(mode);
  }

  setStandardView() {
    SVG.select('rect.grid-fill')['members'][0].attr('display', 'block');
    SVG.select('svg.svgRoot')['members'][0].attr('border', '0px solid red');
    SVG('plots').viewbox(0, 0, 800, 1100);
    SVG('icons').viewbox(0, 0, 800, 1100);
    SVG('grid').viewbox(0, 0, 800, 1100);
    this.gridZoomService.zoomResume();
    this.gridZoomService.standardZoom();
    this.gridZoomService.zoomPause();
  }

  gridOn() {
    const grid = SVG.select('rect.grid-fill')['members'][0];
    grid.attr('stroke-width', '0');
    grid.attr('fill', 'url(/tabs/tab1#biggrid)');
    SVG.select('svg.svgRoot')['members'][0].attr('border', '0px solid red');
    this.resetPrintView();
  }

  displayMenu(menuId: string) {
    switch (menuId) {
      case 'sketch':
        this.gridOn();
        this.gridZoomService.zoomPause();
        this.currentMenu = 'sketch';
        break;
      case 'damage':
        this.gridOn();
        this.gridZoomService.zoomPause();
        this.currentMenu = 'damage';
        this.sketchService.currentIcon = this.damageIcon.DMG_WATER;
        break;
      case 'structure':
        this.gridOn();
        this.gridZoomService.zoomPause();
        this.currentMenu = 'structure';
        break;
      case 'equipment':
        this.gridOn();
        this.gridZoomService.zoomPause();
        this.currentMenu = 'equipment';
        break;
      case 'zoom':
        this.gridOn();
        this.gridZoomService.zoomResume();
        this.currentMenu = 'zoom';
        break;
      case 'print-area':
        this.gridZoomService.zoomPause();
        const grid = SVG.select('rect.grid-fill')['members'][0];
        grid.attr('fill', 'none');
        grid.attr('stroke', 'red');
        grid.attr('stroke-width', '2');
        this.currentMenu = 'print-area';
        break;
      default:
        this.setStandardView();
        this.currentMenu = 'sketch';
        break;
    }
    this.changeDetector.detectChanges();
  }

  resetGrid() {
    this.sketchService.resetGrid();
    this.setFabIcon(this.sketchService.getLastUsedSubstratePattern() + '.svg');
  }

  setDrawStyle(event) {
    this.sketchService.setDrawStyle(event.target.value);
  }

  setFabIcon(name: string) {
    this.fabIcon.next(name);
  }

  setDisplayInfo(icon: IssueIconDescription) {
    this.sketchService.setSelectedIconName(icon);
  }

  // TODO: Refactor this , it's kinda gross
  setMarkerIcon(
    icon: IssueIcon | StructureIcon | EquipmentIcon | EnvironmentIcon,
    type: any,
    e
  ) {
    this.sketchService.setMarkerIcon(icon);
    this.sketchService.setMarkerIconType(IconEnums.getName(type));

    e.stopPropagation();
  }

  setSubstrate(substrate: string, strokeWidth: number, e) {
    this.sketchService.setLastUsedSubstratePattern(substrate);
    this.sketchInstance.currentSubstratePattern = substrate;

    this.sketchService.setSubstrate(
      this.sketchInstance.currentSubstratePattern,
      strokeWidth
    );
    e.stopPropagation();
  }

  estimate(e) {
    e.stopPropagation();
    this.estimateService.estimate();
  }

  startDrawing() {
    this.drawingFileService.createFirstRunDrawing();
  }

  setHighlightMode(b: boolean, e) {
    this.gridZoomService.zoomPause();
    this.sketchInstance.printHighLightActive = b;
    e.stopPropagation();
  }
}
