import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  ViewChild,
} from '@angular/core';
import { EstimateService } from '../../services/estimate/estimate.service';
import { SketchService } from '../../components/sketch/sketch.service';
import { PdfPages, YcsPdfService } from '../../services/ycs-pdf-service/ycs-pdf.service';
import { DrawingFileServicesService } from '../../components/sketch/drawing-file-services.service';
import {
  CompanyInfo,
  DataStorageService,
} from '../../storage/data-storage.service';
import { IconImageModel } from '../../storage/models';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
// import {SizeConstantsService} from '../sketch/size-constants.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
})
export class Tab2Page {
  @ViewChild('customerInfo', { static: true })
  customerInfo: ElementRef;
  @ViewChild('companyInfo', { static: true })
  companyInfo: ElementRef;

  modal;
  productModel = this.estimateService.productModel;
  docUrl = 'http://docs.yourcrawlspace.com/';
  loading: any;
  parser = new DOMParser();
  companyInfo$: Observable<CompanyInfo>;
  companyInfoModel: CompanyInfo = new CompanyInfo();


  constructor(
    private estimateService: EstimateService,
    private sketchService: SketchService,
    private pdfService: YcsPdfService,
    private drawingFileServices: DrawingFileServicesService,
    private datastore: DataStorageService,
    // public scs: SizeConstantsService,
    private changeDetector: ChangeDetectorRef
  ) {
    this.companyInfo$ = this.datastore.companyInfoStore;
    this.companyInfo$.subscribe((info) => {
      this.companyInfoModel = info;
    });
  }

  getDrawingImageForPrint() {
    const html = this.sketchService.sketchComponentInstance.svgContainer.nativeElement as HTMLElement;
    const parser = new DOMParser();
    const newDoc = parser.parseFromString(html.outerHTML, 'text/html');
    const container = newDoc.getElementById('svgContainer');
    container.setAttribute(
      'style',
      `width: 1050px; height: 800px; transform: rotate(90deg);`
    );
    newDoc.getElementById('handle').setAttribute('transform', '');

    const plots = newDoc.getElementById('plots').querySelectorAll('[stroke]');
    plots.forEach((item) => {
      const value = item
        .getAttribute('stroke')
        .toString()
        .replace('/tabs/tab1', '');
      item.setAttribute('stroke', value);
    });

    const root = newDoc.getElementById('svgRoot');

    // convert to image
    const image = this.pdfService.convertSVGToImage(root);
    const canvas = document.getElementById('print-canvas') as HTMLCanvasElement;
    const context = canvas.getContext('2d');
    const img = document.getElementById('drawing-print-image') as HTMLImageElement;
    img.setAttribute('crossOrigin', 'anonymous');
    img.onload = () => {
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.drawImage(img, 0, 0);
    };

    img.src = image.src;

    return image.src; // canvas.toDataURL('image/png');
  }

  exportPdf() {
    const dataUrl = this.getDrawingImageForPrint();

    const estimatePage = document.getElementById('printable-area');

    this.datastore.getAllImagesForDrawing((i: Array<IconImageModel>) => {
      const pages = {
        page1: dataUrl,
        page2: i,
        page3: estimatePage,
      };
      this.pdfService.exportPdf(pages as PdfPages);
    });

    this.changeDetector.detectChanges();
  }
}
