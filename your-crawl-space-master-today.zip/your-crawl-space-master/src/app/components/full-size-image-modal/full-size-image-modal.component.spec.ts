import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FullSizeImageModalComponent } from './full-size-image-modal.component';

describe('FullSizeImageModalComponent', () => {
  let component: FullSizeImageModalComponent;
  let fixture: ComponentFixture<FullSizeImageModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FullSizeImageModalComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FullSizeImageModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
