import { ImageUrlSanitizerPipe } from './image-url-sanitizer.pipe';

describe('ImageUrlSanitizerPipe', () => {
  it('create an instance', () => {
    const pipe = new ImageUrlSanitizerPipe();
    expect(pipe).toBeTruthy();
  });
});
