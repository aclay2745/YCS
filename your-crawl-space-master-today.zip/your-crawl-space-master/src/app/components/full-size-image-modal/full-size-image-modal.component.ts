import { Component, Input, OnInit } from '@angular/core';
import { IconImageModel } from '../../storage/models';
import { ModalController } from '@ionic/angular';
import { ImageModalDataService } from './image-modal-data.service';
import * as panzoom from 'panzoom';

@Component({
  selector: 'app-full-size-image-modal',
  templateUrl: './full-size-image-modal.component.html',
  styleUrls: ['./full-size-image-modal.component.scss'],
})
export class FullSizeImageModalComponent implements OnInit {
  @Input()
  image: IconImageModel;
  pzfs;
  imageData;
  isZoomEnabled = false;
  constructor(
    private modalController: ModalController,
    private imds: ImageModalDataService
  ) {}

  ngOnInit() {
    this.imageData = this.imds.currentImage;
  }

  toggleZoom() {
    if (this.isZoomEnabled) {
      this.pzfs.dispose();
      this.isZoomEnabled = false;
    } else if (!this.isZoomEnabled) {
      this.isZoomEnabled = true;
      const photoDiv = document.getElementById('photo');

      // and forward it it to panzoom.
      // tslint:disable-next-line
      // @ts-ignore
      this.pzfs = panzoom(photoDiv, {
        maxZoom: 3,
        minZoom: 0.5,
      });
    }
  }

  modalClose() {
    this.modalController.dismiss();
  }
}
