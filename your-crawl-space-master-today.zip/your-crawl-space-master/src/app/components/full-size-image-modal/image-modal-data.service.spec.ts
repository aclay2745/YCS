import { TestBed } from '@angular/core/testing';

import { ImageModalDataService } from './image-modal-data.service';

describe('ImageModalDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ImageModalDataService = TestBed.get(ImageModalDataService);
    expect(service).toBeTruthy();
  });
});
