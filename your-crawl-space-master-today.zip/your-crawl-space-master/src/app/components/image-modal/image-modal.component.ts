import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CameraService } from '../../services/camera/camera.service';
import { ModalController } from '@ionic/angular';
import { IconImageStoreModel } from '../../storage/models';
import { DataStorageService } from '../../storage/data-storage.service';
import { SketchService } from '../sketch/sketch.service';
import { IconEnums } from '../sketch/enums';

@Component({
  selector: 'app-image-modal',
  templateUrl: './image-modal.component.html',
  styleUrls: ['./image-modal.component.scss'],
})
export class ImageModalComponent implements OnInit {
  @Output()
  public modalCloseEmitter = new EventEmitter<any>()
  ;
  storedImages;

  constructor(
    private _cameraService: CameraService,
    private modalController: ModalController,
    private datastore: DataStorageService
  ) {}

  ngOnInit() {
    this.datastore.getAllImagesForDrawing((images) => {
      this.storedImages = images;
    });
  }

  modalClose() {
    this.modalController.dismiss();
  }

  getImageName(iconName: number, type: any) {}
}
