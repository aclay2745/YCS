import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ProductSpec } from '../../services/estimate/estimate.service';
import { IonInput } from '@ionic/angular';

@Component({
  selector: 'app-purchase-amount',
  templateUrl: './line-item.component.html',
  styleUrls: ['./line-item.component.scss'],
})
export class LineItemComponent implements OnInit {
  @Input()
  product: ProductSpec;

  @Input()
  docUrl: string;

  @ViewChild('amountRequested', { static: true })
  amountRequested: IonInput;

  rowColor = 'white';

  constructor() {}

  ngOnInit() {}

  increment() {
    this.amountRequested.value =
      Number(this.amountRequested.value) < 99
        ? (Number(this.amountRequested.value) + 1).toString()
        : '99';
    if (this.rowColor === 'lightgrey') {
      this.setWhiteBackground();
    }
  }

  decrement() {
    this.amountRequested.value =
      Number(this.amountRequested.value) > 0
        ? (Number(this.amountRequested.value) - 1).toString()
        : '0';
    if (this.amountRequested.value === '0') {
      this.setGreyBackground();
    }
  }

  notNeeded() {
    this.amountRequested.value = '0';
    this.setGreyBackground();
  }

  setGreyBackground() {
    this.rowColor = 'lightgrey';
  }

  setWhiteBackground() {
    this.rowColor = 'white';
  }

  inputValueChanged(event: KeyboardEvent) {
    const isNumber = isFinite(Number(event.key));

    if (!isNumber) {
      this.amountRequested.value = String(this.amountRequested.value).replace(/[^0-9]/g, '');
      return;
    }

    if (Number(event.key) === 0) {
      this.setGreyBackground();
    }

    if (Number(event.key) > 0) {
      this.setWhiteBackground();
    }
  }
}
