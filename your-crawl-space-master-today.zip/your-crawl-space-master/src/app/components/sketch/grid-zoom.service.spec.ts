import { TestBed } from '@angular/core/testing';

import { GridZoomService } from './grid-zoom.service';

describe('GridZoomService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GridZoomService = TestBed.get(GridZoomService);
    expect(service).toBeTruthy();
  });
});
