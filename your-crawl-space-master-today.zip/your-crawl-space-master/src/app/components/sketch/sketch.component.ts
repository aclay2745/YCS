import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  Renderer2,
  ViewChild,
} from '@angular/core';
import { BehaviorSubject, Subscription, of } from 'rxjs';

import * as SVG from 'svg.js';
import { Guid, PathHelper } from '../../util/utils';
import { EventUtil } from './eventUtil';
import { SketchState } from './sketch-state';
import * as _ from 'lodash';
import { DataStorageService } from '../../storage/data-storage.service';
import { CameraService } from '../../services/camera/camera.service';
import {
  IconEventModel,
  IconImageModel,
  IconsAndPlots,
  SketchStateModel,
  StoredSketchLine,
} from '../../storage/models';
import { IconEnums } from './enums';
import { AlertController, ModalController } from '@ionic/angular';
import { SketchComponentUtil } from './lib/sketch.component.util';
import { IconFactory } from './icon-factory';
import { SketchService } from './sketch.service';
import { EstimateService } from '../../services/estimate/estimate.service';
import { FullSizeImageModalComponent } from '../full-size-image-modal/full-size-image-modal.component';
import { ImageModalDataService } from '../full-size-image-modal/image-modal-data.service';
import { IconSvgService } from '../../services/icon-access-service/icon-svg.service';
import { DrawingFileServicesService } from './drawing-file-services.service';
import { GridZoomService } from './grid-zoom.service';
import Mode = IconEnums.Mode;
import IssueIcon = IconEnums.DamageIcon;
import StructureIcon = IconEnums.StructureIcon;
import EquipmentIcon = IconEnums.EquipmentIcon;
import EnvironmentIcon = IconEnums.EnvironmentIcon;
import DrawStyle = IconEnums.DrawStyle;
import IssueIconDescription = IconEnums.ItemDescriptions;
import { PrintAreaHighlightService } from '../../services/ycs-pdf-service/print-area-highlight.service';
// import {SizeConstantsService} from './size-constants.service';

@Component({
  selector: 'app-sketch',
  templateUrl: './sketch.component.html',
  styleUrls: ['./sketch.component.scss'],
})
export class SketchComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('plots', { static: true })
  plotsRoot: ElementRef;

  @ViewChild('icons', { static: true })
  iconsRoot: ElementRef;

  @ViewChild('zoomRoot', { static: true })
  zoomRoot: ElementRef;

  @ViewChild('zoomImage', { static: true })
  zoomImage: ElementRef;

  @ViewChild('svgRoot', { static: true })
  svgRoot: ElementRef;

  @ViewChild('svgContainer', { static: true })
  svgContainer: ElementRef;

  public mode = Mode;
  public modeSubject: BehaviorSubject<Mode> = new BehaviorSubject(Mode.DRAW);

  public markerIconSubject: BehaviorSubject<
    IssueIcon | StructureIcon | EquipmentIcon | EnvironmentIcon
  > = new BehaviorSubject(null);
  public markerIconTypeSubject: BehaviorSubject<string> = new BehaviorSubject(
    null
  );

  public drawStyleSubject: BehaviorSubject<DrawStyle> = new BehaviorSubject(
    DrawStyle.BLOCK
  );

  public currentIcon:
    | IssueIcon
    | StructureIcon
    | EquipmentIcon
    | EnvironmentIcon;

  public debug = false;
  public sketchState = new SketchState().data();
  public currentSubstratePattern;
  public pz;
  public drawingId: string;
  public sketchService: SketchService;
  public printHighLightActive = false;
  public root;

  protected currentSubstrateStokeWidth;

  private tempSubstratePattern;
  private isErasing: boolean;
  private lineDragging: boolean;
  private pointAdjusting: boolean;
  private previewAdjustmentPoint: SVG.Circle;
  private currentAdjustmentPoint: SVGCircleElement;
  private currentAdjustLine: StoredSketchLine;
  private cameraActive: boolean;
  private cameraActiveSub: Subscription;
  private gridSnapping; // TODO: Set up snapping options
  private iconAdjusting: boolean;
  private currentIconAdjustmentObjects;
  private currentLineLengthSVG: SVG.Doc;
  private startupRun = true;
  private lastRotation = 0;

  private point;

  constructor(
    private localStorage: DataStorageService,
    private cameraService: CameraService,
    public alertController: AlertController,
    public modalController: ModalController,
    private renderer: Renderer2,
    private elRef: ElementRef,
    private _sketchService: SketchService,
    private estimateService: EstimateService,
    private imds: ImageModalDataService,
    private iconSvgService: IconSvgService,
    private drawingFileService: DrawingFileServicesService,
    private gridZoomService: GridZoomService,
    private printDataService: PrintAreaHighlightService
  ) {
    this.cameraActiveSub = this.cameraService.cameraActive.subscribe((v) => {
      this.cameraActive = v;
    });

    this.sketchService = _sketchService;

    // cache some images
    const images = [];
    images[0] = new Image().src = '../../../assets/SUB_BRICK.svg';
    images[1] = new Image().src = '../../../assets/SUB_STONE.svg';
    images[2] = new Image().src = '../../../assets/SUB_BLOCK.svg';
    images[3] = new Image().src = '../../../assets/SUB_FENCE.svg';
    images[4] = new Image().src = '../../../assets/SUB_DRAINLINE.svg';
    images[5] = new Image().src = '../../../assets/SUB_DUCTLINE.svg';
    images[6] = new Image().src = '../../../assets/SUB_PUMPLINE.svg';
  }

  ngOnInit() {
    this.attachEventHandlers();
    this.gridZoomService.zoomSetup(document.getElementById('handle'));
    this.gridZoomService.zoomPause();
  }

  getPlotsAndSIconsSVG(): IconsAndPlots {
    return {
      plotsRoot: document.getElementById('plots').innerHTML,
      iconRoot: document.getElementById('icons').innerHTML,
    };
  }

  loadPlots(svgString: string) {
    document.getElementById('plots').innerHTML = svgString;
  }

  loadIcons(svgString: string) {
    document.getElementById('icons').innerHTML = svgString;
  }

  ngOnDestroy(): void {
    this.cameraActiveSub.unsubscribe();
  }

  ngAfterViewInit(): void {
    this.localStorage.getDrawingCount((count) => {
      // console.log('edatastore count', count);
      if (count === 0) {
        this.drawingFileService.createFirstRunDrawing();
      }
      this.drawingFileService.totalStoredDrawings = count;
    });
  }

  async presentAlertConfirm() {
    const alert = await this.alertController.create({
      header: 'Confirm!',
      message:
        'Are you sure you want to COMPLETELY erase this sketch? The action cannot be undone.',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Cancelled grid reset');
          },
        },
        {
          text: 'Okay',
          handler: () => {
            this.confirmedGridReset();
          },
        },
      ],
    });

    await alert.present();
  }

  attachEventHandlers() {
    // Attach event handlers
    document.getElementById('svgContainer').ontouchstart = (event) => {
      // event.preventDefault();
      console.log('ontouchstart event ~> ', event);
      this.onEventDown(event);
    };

    document.getElementById('svgContainer').ontouchend = (event) => {
      // event.preventDefault();
      console.log('ontouchend event ~> ', event);
      this.onEventUp(event);
    };

    document.getElementById('svgContainer').ontouchmove = (event) => {
      // event.preventDefault();
      console.log('ontouchmove event ~> ', event);
      this.onEventMove(event);
    };

    // Attach the plots to the zoomRoot via <use> element
    SVG('zoomRoot').use(SVG('plots'));
  }

  zoom(level: number) {
    const viewPort = SVG('svgRoot').viewbox();
    viewPort.zoom = level;
  }

  setMode(m: Mode) {
    IconFactory.hideAllIconMenus();

    if (m === Mode.DRAW) {
      this.toggleEndpoints(false);
    }

    if (m === Mode.ADJUST) {
      this.toggleEndpoints(true);
    }

    this.modeSubject.next(m);
  }

  setCurrentIcon(i: IssueIcon | EquipmentIcon | StructureIcon) {
    this.currentIcon = i;
  }

  setDrawStyle(style: DrawStyle) {
    this.drawStyleSubject.next(style);
  }

  resetGrid() {
    const promise = this.presentAlertConfirm();
  }

  isPreviewUndefined() {
    return (
      this.sketchState.previewLine !== undefined &&
      this.sketchState.previewLineEndPoint !== undefined
    );
  }

  setMarkerIcon(
    icon: IssueIcon | StructureIcon | EquipmentIcon | EnvironmentIcon
  ) {
    this.markerIconSubject.next(icon);
  }

  setMarkerIconType(iconType: string) {
    this.markerIconTypeSubject.next(iconType);
  }

  cleanUpPreviewLine(s: SketchStateModel) {
    s.previewLine = undefined;
    this.lineDragging = false;
    s.startTargetX = undefined;
    s.startTargetY = undefined;
    s.previewLineStartPoint = undefined;
    s.previewLineEndPoint = undefined;
  }

  setSubstrate(substrate: string, strokeWidth: number) {
    this.currentSubstratePattern = substrate;
    this.currentSubstrateStokeWidth = strokeWidth;
  }

  confirmedGridReset() {
    this.sketchService.setSqft(0);
    this.sketchService.setCurrentLineLength(0);
    this.sketchService.setPerimeter(0);
    this.sketchService.setSelectedIconName(IssueIconDescription.SUB_BRICK);
    this.estimateService.pierCount1616.next(0);
    this.sketchService.storedLineRedoStack = [];

    _.each(SketchComponentUtil.getAllLines(), (line: SVG.Element) => {
      line.remove();
    });

    _.each(SketchComponentUtil.getAllGridPaths(), (path: SVG.Element) => {
      path.remove();
    });

    _.each(SketchComponentUtil.getAllPoints(), (point: SVG.Element) => {
      point.remove();
    });

    _.each(SketchComponentUtil.getAllIcons(), (icon: SVG.Element) => {
      icon.remove(); // TODO: Remove all images associated with the icons from the database
    });

    _.each(SketchComponentUtil.getAllIconFrames(), (iconFrame: SVG.Element) => {
      iconFrame.remove();
    });

    _.each(
      SketchComponentUtil.getAllIconContainers(),
      (iconContainer: SVG.Element) => {
        iconContainer.remove();
      }
    );

    _.each(SketchComponentUtil.getAllIconMenus(), (iconMenu: SVG.Element) => {
      iconMenu.remove();
    });

    _.each(
      SketchComponentUtil.getAllEstimatePolygons(),
      (polygon: SVG.Element) => {
        polygon.remove();
      }
    );

    IconFactory.removeAllIconHighlights();

    this.sketchService.sketchComponentInstance.sketchState.lineArray = [];
  }

  public toggleEndpoints(flag: boolean) {
    if (flag) {
      // Get all points available to adjust and show them
      this.sketchState.lineArray.forEach((line) => {
        line.points[0].attr('opacity', String(1));
        line.points[1].attr('opacity', String(1));
      });
      return;
    }

    this.sketchState.lineArray.forEach((line) => {
      line.points[0].attr('opacity', String(0));
      line.points[1].attr('opacity', String(0));
    });
  }

  async presentModal(image) {
    this.imds.currentImage = image;
    const modal = await this.modalController.create({
      component: FullSizeImageModalComponent,
      componentProps: {
        image,
      },
    });
    return await modal.present();
  }

  calculateTrueLine(line) {
    return Number(
      (Math.round(SketchComponentUtil.distance(line)) / 12).toFixed(2)
    );
  }

  undoLastLine() {
    const linesLength = this.sketchState.lineArray.length;

    if (linesLength > 0) {
      this.zeroOutCalculationDisplay();

      const popped = this.sketchState.lineArray.pop();
      this.sketchService.storedLineRedoStack.push(popped);

      popped.line.remove();
      popped.substratePath.remove();
      popped.points[0].remove();
      popped.points[1].remove();
      this.estimateService.estimate();
    }
  }

  redoLastLine() {
    const stackLength = this.sketchService.storedLineRedoStack.length;

    if (stackLength > 0) {
      this.zeroOutCalculationDisplay();
      const popped = this.sketchService.storedLineRedoStack.pop();

      this.sketchState.lineArray.push(popped);

      SVG('plots').add(popped.substratePath);
      SVG('plots').add(popped.line);
      SVG('plots').add(popped.points[0]);
      SVG('plots').add(popped.points[1]);
      this.estimateService.estimate();
    }
  }

  private onEventDown(event) {
    this.point = EventUtil.getPointFromEvent(event);
    console.log('onEventDown point ~> ', this.point);
    switch (this.modeSubject.value) {
      case Mode.DRAW:
        console.log('onEventDown DRAW ~> ', event);
        this.drawStart(event);
        break;
      case Mode.ERASE:
        console.log('onEventDown ERASE', event);
        // console.log("SketchComponentUtil.getAllGridPaths() ~> ", SketchComponentUtil.getAllGridPaths());
        // console.log("SketchComponentUtil.getAllPoints() ~> ", SketchComponentUtil.getAllPoints());
        _.each(SketchComponentUtil.getAllGridPaths(), (path: SVG.Element) => {
          // console.log("svg path ~> ", path);
          path.front();
        });

        _.each(SketchComponentUtil.getAllPoints(), (p: SVG.Element) => {
          // console.log("svg points ~> ", p);
          p.front();
        });

        this.isErasing = true;
        console.log('this ~> ', this);
        break;
      case Mode.ADJUST:
        //  Gets the element stack at this x / y coordinate and
        //  filters by CSS class to get any element with a 'sketch-point' class
        const elements = document
          .elementsFromPoint(this.point.x, this.point.y)
          .filter((e) =>
            e.classList.contains('sketch-point')
          ) as Array<Element>;

        // Currently grabs the top element in the stack TODO: Option to grab all elements in the stack
        this.currentAdjustmentPoint = elements[0] as SVGCircleElement;

        if (this.currentAdjustmentPoint !== undefined) {
          if (this.currentAdjustmentPoint.classList.contains('sketch-point')) {
            this.previewAdjustmentPoint = undefined;
            this.pointAdjusting = true;
          }
        }

        break;
      case Mode.ICON_ADJUST:
        //  Gets the element stack at this x / y coordinate and
        //  filters by CSS class to get any elements with the specified classes
        const adjustmentElements = document
          .elementsFromPoint(this.point.x, this.point.y)
          .filter(
            (e) =>
              e.classList.contains('rotate-arrow-left') ||
              e.classList.contains('rotate-arrow-right') ||
              e.classList.contains('icon-highlight')
          ) as Array<Element>;

        // make sure the mouse is clicking on a rotation arrow or the highlight rectangle
        if (_.size(adjustmentElements) > 0) {
          this.iconAdjusting = true;
          const className = adjustmentElements[0].className['baseVal'];
          const id =
            adjustmentElements[0].attributes.getNamedItem('naked-id').value;
          const iconAndFrame = IconFactory.getIconAndFrameById(id);
          const highlightAndHandles =
            IconFactory.getHighlightAndHandlesById(id);

          this.currentIconAdjustmentObjects = {
            iconAndFrame,
            highlightAndHandles,
            activeClassName: className,
          };
          let set;
          switch (className) {
            case 'rotate-arrow rotate-arrow-left':
              set = SVG('icons').select('#' + id + '_container_group');
              set.get(0).rotate(this.lastRotation + 90);
              this.lastRotation = this.lastRotation + 90;

              break;
            case 'rotate-arrow rotate-arrow-right':
              set = SVG('icons').select('#' + id + '_container_group');
              set.get(0).rotate(this.lastRotation + 90);
              this.lastRotation = this.lastRotation + 90;
              break;
          }
        }

        break;
      case Mode.PRINT_AREA:
        if (this.printHighLightActive) {
          this.gridZoomService.zoomPause();
          this.printDataService.printAreaMouseDown(event);
        } else {
          // panzoom
          this.gridZoomService.zoomResume();
        }

        break;
    }
  }

  private onEventUp(event) {
    switch (this.modeSubject.value) {
      case Mode.DRAW:
        this.drawEnd(event);
        this.estimateService.estimate();
        break;
      case Mode.ERASE:
        console.log('onEventUp ERASE ~> ', event);
        // _.each(SketchComponentUtil.getAllGridPaths(), (path: SVG.Element) => {
        //     path.back();
        // });
        // this.isErasing = false;
        this.estimateService.estimate();
        break;
      case Mode.ADJUST:
        _.each(SketchComponentUtil.getAllPoints(), (circ: SVG.Circle) => {
          circ.attr('stroke', 'none');
        });

        _.each(SketchComponentUtil.getAllGhostPoints(), (gp: SVG.Circle) => {
          gp.remove();
        });

        if (this.currentAdjustLine !== undefined) {
          this.currentAdjustLine.substratePath = this.addSubstrateToLine(
            this.currentAdjustLine.line
          );
        }

        this.pointAdjusting = false;
        this.currentAdjustLine = undefined;

        if (this.previewAdjustmentPoint !== undefined) {
          this.previewAdjustmentPoint.remove();
        }

        this.currentSubstratePattern = this.tempSubstratePattern;
        this.estimateService.estimate();
        SketchComponentUtil.toggleLengthBubble(false);
        break;
      case Mode.ICON:
        console.log('onEventUp ICON ~> ', event);
        const forStorage: IconImageModel = {
          imageId: '',
          drawingId: this.drawingId,
          data: null,
          iconType: '',
          iconName: '',
          notes: '',
        };

        const eventModel: IconEventModel = {
          event,
          markerIconSubject: this.markerIconSubject,
          markerIconTypeSubject: this.markerIconTypeSubject,
          cameraService: this.cameraService,
          forStorage,
          estimateService: this.estimateService,
        };

        const iconEventResult = IconFactory.iconEvent(
          this.iconSvgService,
          eventModel,
          (image) => {
            // called when the image needs to be seen fullscreen
            this.presentModal(image);
          }
        );

        console.log('iconEventResult ~> ', iconEventResult);
        if (iconEventResult === 1) {
          this.setMode(Mode.ICON_ADJUST);
          break;
        }

        break;
      case Mode.ICON_ADJUST:
        setTimeout(() => {
          this.setMode(Mode.ICON);
        }, 100);
        IconFactory.removeAllIconHighlights();

        this.iconAdjusting = false;
        break;
      case Mode.PRINT_AREA:
        break;
    }
  }

  private onEventMove(event) {
    switch (this.modeSubject.value) {
      case Mode.DRAW:
        this.drawing(event);
        break;
      case Mode.ERASE:
        this.erasing(event);
        break;
      case Mode.ADJUST:
        this.adjusting(event);
        break;
      case Mode.ICON_ADJUST:
        if (this.iconAdjusting) {
          // let's grab the active transform controls
          // and move or rotate some stuff
          const transformType =
            this.currentIconAdjustmentObjects.activeClassName;
          const svgP = SketchComponentUtil.domToSVG(event);

          IconFactory.moveIcon(this.currentIconAdjustmentObjects, svgP);
        }
        break;
    }
  }

  private drawStart(event) {
    const svgP = SketchComponentUtil.domToSVG(event);
    const s = this.sketchState;
    s.startTargetX =
      Math.round(svgP.x / this.sketchState.gridOpts.grid) *
      this.sketchState.gridOpts.grid;
    s.startTargetY =
      Math.round(svgP.y / this.sketchState.gridOpts.grid) *
      this.sketchState.gridOpts.grid;
    s.previewLineStartPoint = SketchComponentUtil.createControlPoint(
      s.startTargetX,
      s.startTargetY
    );

    /*const guid = 'ycs_' + String(Guid.newGuid());
        this.currentLineLengthSVG = SVG('plots').svg(guid);*/
    /*
        if (s.lineArray.length >= 1) {
            const isPreviousLineSubComp = s.lineArray[s.lineArray.length - 1].isComputationalSub;
           const isCurrentLineSubComp = SketchComponentUtil.isComputationalSub(this.currentSubstratePattern);


            if (isPreviousLineSubComp && isCurrentLineSubComp) {
                s.startTargetX = s.lineArray[s.lineArray.length - 1].points[1].cx();
                s.startTargetY = s.lineArray[s.lineArray.length - 1].points[1].cy();
            } else {
                s.startTargetX = Math.round(svgP.x / this.sketchState.gridOpts.grid) * this.sketchState.gridOpts.grid;
                s.startTargetY = Math.round(svgP.y / this.sketchState.gridOpts.grid) * this.sketchState.gridOpts.grid;
            }
        } else {
            s.startTargetX = Math.round(svgP.x / this.sketchState.gridOpts.grid) * this.sketchState.gridOpts.grid;
            s.startTargetY = Math.round(svgP.y / this.sketchState.gridOpts.grid) * this.sketchState.gridOpts.grid;
        }

        // start drawing from the last point that is a substrate
        s.previewLineStartPoint = SketchComponentUtil.createControlPoint(s.startTargetX, s.startTargetY);*/

    this.lineDragging = true;
  }

  private drawEnd(event) {
    const s = this.sketchState;

    // Fixes bug where a single dot can be placed without a line
    if (s.previewLine === undefined) {
      if (s.previewLineStartPoint) {
        s.previewLineStartPoint.remove();
        SketchComponentUtil.toggleLengthBubble(false);
      }
    }

    if (s.previewLine !== undefined) {
      const lineLength = SketchComponentUtil.distance(s.previewLine);

      if (lineLength < 12) {
        s.previewLineStartPoint.remove();
        s.previewLineEndPoint.remove();
        this.cleanUpPreviewLine(s);
        return;
      }

      const substratePath = this.addSubstrateToLine(s.previewLine);

      s.previewLine.attr('naked-id', 'ycs_' + Guid.newGuid());

      s.lineArray.push({
        line: s.previewLine,
        points: [s.previewLineStartPoint, s.previewLineEndPoint],
        substratePath,
        isComputationalSub: SketchComponentUtil.isComputationalSub(
          this.currentSubstratePattern
        ),
        substratePattern: this.currentSubstratePattern,
      } as StoredSketchLine);

      // Hide the points until the node edit is active
      s.previewLineStartPoint.attr('opacity', String(0));
      s.previewLineEndPoint.attr('opacity', String(0));
    }
    SketchComponentUtil.toggleLengthBubble(false);
    this.cleanUpPreviewLine(s);
  }

  // Used to draw a line
  private drawing(event) {
    if (this.lineDragging) {
      //  const bubbles = this.currentLineLengthSVG.select('')['members'];

      const opts = this.sketchState.lineOpts;

      const svgP = SketchComponentUtil.domToSVG(event);

      // if (this.isPreviewUndefined()) {
      //     SVG('plots').removeElement(<SVG.Line>this.sketchState.previewLine);
      //     SVG('plots').removeElement(<SVG.Circle>this.sketchState.previewLineEndPoint);
      // }

      if (this.isPreviewUndefined()) {
        SVG('plots').removeElement(this.sketchState.previewLine as SVG.Line);
        SVG('plots').removeElement(
          this.sketchState.previewLineEndPoint as SVG.Circle
        );
      }

      // Enables snapping
      const x2 =
        Math.round(svgP.x / this.sketchState.gridOpts.grid) *
        this.sketchState.gridOpts.grid;
      const y2 =
        Math.round(svgP.y / this.sketchState.gridOpts.grid) *
        this.sketchState.gridOpts.grid;

      /*add an if else here to turn snapping on or off*/
      // const x2 =  point.x;
      // const y2 =  point.y;

      const line = new SVG.Line();

      line.attr({
        x1: this.sketchState.startTargetX,
        y1: this.sketchState.startTargetY,
        x2,
        y2,
        stroke: opts.stroke,
        'stroke-width': opts['stroke-width'],
        class: 'sketch-line',
      });

      this.sketchState.previewLine = line;

      SVG('plots').add(line);

      SketchComponentUtil.updateViewBox(x2, y2);
      this.sketchState.previewLineEndPoint =
        SketchComponentUtil.createControlPoint(x2, y2);

      this.updateLastLength(line);
    }
  }

  private updateLastLength(line) {
    const lineLength = this.calculateTrueLine(line);

    if (lineLength >= 8) {
      SketchComponentUtil.updateLineLengthBubbleLocation(line);
      SketchComponentUtil.toggleLengthBubble(true);
    } else {
      SketchComponentUtil.toggleLengthBubble(false);
    }

    // display the length of the line
    this.sketchService.setCurrentLineLength(lineLength);
    return lineLength;
  }

  /*Creates a path with an assigned stroke pattern*/

  private addSubstrateToLine(line: SVG.Line): SVG.Path {
    const x1 = line.attr('x1');
    const x2 = line.attr('x2');
    const y1 = line.attr('y1');
    const y2 = line.attr('y2');
    const length = this.sketchService.currentLineLength;
    const d = `M${x2},${y2}l${x1 - x2},${y1 - y2}`;
    const angle = PathHelper.getAngleInDegrees(line);

    // get the pattern and transform it
    const pattern = document.getElementById(this.currentSubstratePattern);

    /* if (angle === 90) {

         }*/

    pattern.style.setProperty('transform', 'none');
    pattern.style.setProperty('transform', 'rotate(' + (angle - 90) + 'deg)');

    const path = new SVG.Path();
    path
      .attr('d', d)
      .attr('stroke-width', this.currentSubstrateStokeWidth)
      .attr('stroke-linecap', 'round')
      .attr('stroke', 'url(/tabs/tab1#' + this.currentSubstratePattern + ')')
      .attr('naked-id', line.id())
      .addClass('substrate');

    path.addTo(SVG('plots'));
    path.back();
    return path;
  }

  private erasing(event) {
    if (this.isErasing) {
      const svgP = SketchComponentUtil.domToSVG(event);
      console.log(
        'SketchComponentUtil.domToSVG(event) ~> ',
        SketchComponentUtil.domToSVG(event)
      );

      //  Gets the element stack at this SVG transformed coordinate and
      //  filters by CSS class to get any element with a 'sketch-line' class
      // or an 'issue-icon' class or a substrate
      // TODO: Implement a 'deletable' selector to simplify the deletion process
      const ele = document
        .elementsFromPoint(svgP.x, svgP.y)
        .filter(
          (e) =>
            e.classList.contains('sketch-line') ||
            e.classList.contains('issue-icon') ||
            e.classList.contains('icon-frame-overlay') ||
            e.classList.contains('issue-icon-frame') ||
            e.classList.contains('substrate')
        ) as Array<Element>;

      ele.forEach((e) => {
        if (e.classList.contains('substrate')) {
          const sl: StoredSketchLine = _.find(
            this.sketchState.lineArray,
            (el1: StoredSketchLine) =>
              el1.substratePath.attr('naked-id') === e.getAttribute('naked-id')
          );

          this.sketchService.storedLineRedoStack.push(sl);
          sl.substratePath.remove();
          sl.line.remove();
          sl.points[0].remove();
          sl.points[1].remove();

          _.remove(
            this.sketchState.lineArray,
            (e2) =>
              e2.substratePath.attr('naked-id') === e.getAttribute('naked-id')
          );
        }

        if (
          e.classList.contains('issue-icon') ||
          e.classList.contains('issue-icon-frame')
        ) {
          document.getElementById('icons').removeChild(e);
        }
      });

      this.isErasing = false;
    }
  }

  private adjusting(event) {
    if (this.pointAdjusting) {
      const svgP = SketchComponentUtil.domToSVG(event);

      const cid = this.currentAdjustmentPoint.id;

      if (this.currentAdjustLine === undefined) {
        this.currentAdjustLine = _.find(
          this.sketchState.lineArray,
          (el1: StoredSketchLine) =>
            el1.points[1].node.id === cid || el1.points[0].node.id === cid
        );
      }

      if (this.previewAdjustmentPoint !== undefined) {
        this.previewAdjustmentPoint.remove();
      }

      // IOS bug fix. Safari for some reason loses the path render right out of the gate
      // So, this forces a quick redraw
      if (this.startupRun) {
        document.getElementById('plots').style.display = 'none';
        document.getElementById('plots').style.display = 'block';
        this.startupRun = false;
      }

      this.previewAdjustmentPoint = SketchComponentUtil.createGhostPoint(
        svgP.x,
        svgP.y
      );
      this.tempSubstratePattern = this.currentSubstratePattern;
      this.currentSubstratePattern = this.currentAdjustLine.substratePattern;

      // delete the substrate path
      this.currentAdjustLine.substratePath.remove();

      const xPoint =
        Math.round(svgP.x / this.sketchState.gridOpts.grid) *
        this.sketchState.gridOpts.grid;
      const yPoint =
        Math.round(svgP.y / this.sketchState.gridOpts.grid) *
        this.sketchState.gridOpts.grid;

      this.previewAdjustmentPoint.attr('cx', xPoint);
      this.previewAdjustmentPoint.attr('cy', yPoint);

      if (this.currentAdjustLine.points[0].node.id === cid) {
        this.currentAdjustLine.points[0].attr('cx', xPoint);
        this.currentAdjustLine.points[0].attr('cy', yPoint);
        this.currentAdjustLine.line.attr('x1', xPoint);
        this.currentAdjustLine.line.attr('y1', yPoint);
      }

      if (this.currentAdjustLine.points[1].node.id === cid) {
        this.currentAdjustLine.points[1].attr('cx', xPoint);
        this.currentAdjustLine.points[1].attr('cy', yPoint);
        this.currentAdjustLine.line.attr('x2', xPoint);
        this.currentAdjustLine.line.attr('y2', yPoint);
      }

      SketchComponentUtil.updateLineLengthBubbleLocation(
        this.currentAdjustLine.line
      );
      SketchComponentUtil.updateViewBox(xPoint, yPoint);
      this.updateLastLength(this.currentAdjustLine.line);

      // clean up empty svgjs defs
      // This is a gross bug in svg.js
      const eles = document.getElementsByTagName('defs');

      _.forEach(eles, (ele: SVGDefsElement) => {
        if (ele !== undefined) {
          if (ele.innerHTML === '') {
            ele.remove();
          }
        }
      });
    }
  }

  private zeroOutCalculationDisplay() {
    this.sketchService.setSqft(0);
    this.sketchService.setCurrentLineLength(0);
    this.sketchService.setPerimeter(0);
  }
}
