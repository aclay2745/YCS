import { EventEmitter, Injectable, Output } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { SketchComponent } from './sketch.component';
import { IconEnums } from './enums';
import { of } from 'rxjs';
import { StoredSketchLine } from '../../storage/models';
import { DataStorageService } from '../../storage/data-storage.service';
import { Guid } from '../../util/utils';
import Mode = IconEnums.Mode;
import IssueIcon = IconEnums.DamageIcon;
import StructureIcon = IconEnums.StructureIcon;
import EquipmentIcon = IconEnums.EquipmentIcon;
import EnvironmentIcon = IconEnums.EnvironmentIcon;
import DrawStyle = IconEnums.DrawStyle;
import { IonTabs } from '@ionic/angular';

@Injectable({
  providedIn: 'root',
})
export class SketchService {
  @Output()
  undo: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  redo: EventEmitter<any> = new EventEmitter<any>();

  selectedIcon;
  currentMode: Mode;
  modeSubject: BehaviorSubject<Mode>;
  mode = Mode;
  currentIcon: IssueIcon | StructureIcon | EquipmentIcon | EnvironmentIcon;
  issueIcon = IssueIcon;
  sketchComponentInstance: SketchComponent;
  lastUsedSubstratePattern: BehaviorSubject<string> =
    new BehaviorSubject<string>('SUB_BRICK');
  lastUsedIcon;
  sqfeet: Observable<number> = of(0);
  currentLineLength: Observable<number> = of(0);
  selectedIconName: Observable<string>;
  storedLineRedoStack: Array<StoredSketchLine> = [];

  ycsTabs: IonTabs;

  private perimeter: BehaviorSubject<number> = new BehaviorSubject<number>(0);

  constructor(private _dataStorage: DataStorageService) {}

  setSketchComponentInstance(sci: SketchComponent) {
    this.sketchComponentInstance = sci;
  }

  getIconRoot(): SVGElement {
    return this.sketchComponentInstance.iconsRoot.nativeElement as SVGElement;
  }

  getPlotsRoot(): SVGElement {
    return this.sketchComponentInstance.plotsRoot.nativeElement as SVGElement;
  }

  getSVGRoot(): SVGElement {
    return this.sketchComponentInstance.svgRoot.nativeElement as SVGElement;
  }

  getSVGContainer(): SVGElement {
    return this.sketchComponentInstance.svgRoot.nativeElement as SVGElement;
  }

  getLineArray(): Array<StoredSketchLine> {
    return this.sketchComponentInstance.sketchState.lineArray;
  }

  resetGrid() {
    // const d = new Date();
    // const storage: StorageObject = {
    //     createdDate: d,
    //     display: 'Test',
    //     drawingId: this.sketchComponentInstance.drawingId,
    //     id: -1,
    //     lastModified: d,
    //     svgDocument: {
    //         iconRoot: this.getIconRoot().innerHTML,
    //         plotsRoot: this.getPlotsRoot().innerHTML
    //     },
    //     lineArray: JSON.stringify(this.getLineArray())
    // };

    // this._dataStorage.storeSVGDoc(storage);
    this.sketchComponentInstance.resetGrid();
    this.sketchComponentInstance.drawingId = Guid.newGuid();

    // console.log(storage);
  }

  setMode(mode: Mode) {
    this.sketchComponentInstance.setMode(mode);
  }

  setCurrentIcon(icon: IssueIcon | EquipmentIcon | StructureIcon) {
    this.sketchComponentInstance.setCurrentIcon(icon);
  }

  setLastUsedIcon(icon: IssueIcon | EquipmentIcon | StructureIcon) {
    this.lastUsedIcon = icon;
  }

  setLastUsedSubstratePattern(pattern: string) {
    this.lastUsedSubstratePattern.next(pattern);
  }

  getLastUsedSubstratePattern() {
    let sub = this.lastUsedSubstratePattern.value;

    if (sub === '' || sub === undefined) {
      sub = 'SUB_BRICK';
    }

    return sub;
  }

  setDrawStyle(style: DrawStyle) {
    this.sketchComponentInstance.setDrawStyle(style);
  }

  setMarkerIcon(
    icon: IssueIcon | StructureIcon | EquipmentIcon | EnvironmentIcon
  ) {
    this.sketchComponentInstance.setMarkerIcon(icon);
  }

  setMarkerIconType(iconType: string) {
    this.sketchComponentInstance.setMarkerIconType(iconType);
  }

  setSubstrate(substrate: string, strokeWidth: number) {
    this.sketchComponentInstance.setSubstrate(substrate, strokeWidth);
  }

  setSqft(sqft: number) {
    this.sqfeet = of(sqft);
  }

  getSqft() {
    return this.sqfeet;
  }

  setPerimeter(value: number) {
    this.perimeter.next(value);
  }

  getPerimeter() {
    return this.perimeter;
  }

  setCurrentLineLength(length: number) {
    this.currentLineLength = of(length);
  }

  getCurrentLineLength() {
    return this.currentLineLength;
  }

  setSelectedIconName(name: string) {
    this.selectedIconName = of(name);
  }

  getSelectedIconName() {
    return this.selectedIconName;
  }

  undoLastLine() {
    this.sketchComponentInstance.undoLastLine();
  }

  redoLastLine() {
    this.sketchComponentInstance.redoLastLine();
  }
}
