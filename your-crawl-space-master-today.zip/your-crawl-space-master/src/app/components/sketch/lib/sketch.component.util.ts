import * as SVG from 'svg.js';
import { EventUtil } from '../eventUtil';
import { StoredSketchLine } from '../../../storage/models';
import { Guid } from '../../../util/utils';

export class SketchComponentUtil {
  public static getAllIcons(): SVG.Set {
    return SVG.select('use.issue-icon')['members'];
  }

  public static setPointColor(event, color: string) {
    const point = EventUtil.getPointFromEvent(event);
    const ele = document.elementFromPoint(point.x, point.y);
    const cir: SVG.Element = SVG.get(ele.id);

    cir.fill(color);
  }

  public static getAllIconFrames(): SVG.Set {
    return SVG.select('use.issue-icon-frame')['members'];
  }

  public static getAllIconContainers(): SVG.Set {
    return SVG.select('svg.icon-container')['members'];
  }

  public static getAllIconMenus(): SVG.Set {
    return SVG.select('use.icon-menu')['members'];
  }

  public static getAllIconMenuItemIcons(): SVG.Set {
    return SVG.select('use.icon-menu-icon')['members'];
  }

  public static getAllLines(): SVG.Set {
    return SVG.select('line.sketch-line')['members'];
  }

  public static getAllGridPaths() {
    return SVG.select('path.substrate')['members'];
  }

  public static getAllPoints(): SVG.Set {
    return SVG.select('circle.sketch-point')['members'];
  }

  public static getAllGhostPoints(): SVG.Set {
    return SVG.select('circle.ghost-point')['members'];
  }

  public static getAllEstimatePolygons(): SVG.Set {
    return SVG.select('polygon.estimate-polygon')['members'];
  }

  public static getAllEstimatePolylines(): SVG.Set {
    return SVG.select('polyline.estimate-polygon')['members'];
  }

  // Measures the length of a line
  public static distance(line: SVG.Line) {
    const x1 = Number(line.attr('x1'));
    let x2 = Number(line.attr('x2'));
    const y1 = Number(line.attr('y1'));
    let y2 = Number(line.attr('y2'));

    const result = Math.sqrt((x2 -= x1) * x2 + (y2 -= y1) * y2);

    return result;
  }

  public static createControlPoint(x: number, y: number): SVG.Circle {
    const c = SVG('plots').circle(20);
    c.attr('cx', x);
    c.attr('cy', y);
    c.attr('fill', '#ff4a00');
    c.attr('class', 'sketch-point');

    return c;
  }

  public static createGhostPoint(x: number, y: number): SVG.Circle {
    const c = SVG('grid').circle(52);
    c.attr('cx', x);
    c.attr('cy', y);
    c.attr('fill', 'green');
    c.attr('fill-opacity', '0.1');
    c.attr('class', 'ghost-point');
    c.front();
    return c;
  }

  // Requires updateViewBox to work
  public static toggleFingerView() {
    const zoomRoot = document.getElementById('zoomRoot');
    if (zoomRoot.style.display === 'block') {
      zoomRoot.style.display = 'none';
    } else {
      zoomRoot.style.display = 'block';
    }
  }

  public static setFingerViewLocation(event) {
    const zoomRoot = document.getElementById('zoomRoot');
    const w = Math.max(
      document.documentElement.clientWidth,
      window.innerWidth || 0
    );
    const h = Math.max(
      document.documentElement.clientHeight,
      window.innerHeight || 0
    );

    const point = EventUtil.getPointFromEvent(event);

    if (point.y < h - 125 && point.x < w - 125) {
      zoomRoot.style.left = String(point.x - 175);
      zoomRoot.style.top = String(point.y - 250);
    } else {
      zoomRoot.style.left = String(point.x - 350);
      zoomRoot.style.top = String(point.y - 500);
    }

    // TODO: Revist roving finger view
    // if (point.x <= w / 2 && point.y >= h / 2) {
    //     if (zoomRoot.classList.contains('zoom-view-location-1')) {
    //         zoomRoot.classList.remove('zoom-view-location-1');
    //     }
    //     zoomRoot.classList.add('zoom-view-location-2');
    // } else if (point.x >= w / 2 && point.y >= h / 2) {
    //     if (zoomRoot.classList.contains('zoom-view-location-2')) {
    //         zoomRoot.classList.remove('zoom-view-location-2');
    //     }
    //     zoomRoot.classList.add('zoom-view-location-1');
    // }
  }

  public static updateLineLengthBubbleLocation(line: SVG.Line) {
    const bubble = document.getElementById('lineLengthBubble');

    const point = SketchComponentUtil.svgCoordsToDOMCoords(
      line.cx(),
      line.cy()
    );

    bubble.style.left = String(point.x - 16) + 'px';
    bubble.style.top = String(point.y - 16) + 'px';
  }

  public static toggleLengthBubble(flag: boolean) {
    const bubble = document.getElementById('lineLengthBubble');

    if (!flag) {
      bubble.style.display = 'none';
    } else {
      bubble.style.display = 'block';
    }
  }

  public static updateViewBox(x, y) {
    SVG('zoomRoot').viewbox(x - 25, y - 25, 5, 5);
  }

  public static domToSVG(event) {
    const plots = SVG('plots');
    const p = new SVG.Point();

    if (event.touches.length > 0) {
      event.x = p.x = (event.touches as TouchList)[0].clientX;
      event.y = p.y = (event.touches as TouchList)[0].clientY;
    } else {
      event.x = p.x = (event.changedTouches as TouchList)[0].clientX;
      event.y = p.y = (event.changedTouches as TouchList)[0].clientY;
    }

    return p.transform(plots.screenCTM().inverse());
  }

  public static domCoordsToSvgCoords(x: number, y: number) {
    const plots = SVG('plots');
    const p = new SVG.Point();

    p.x = x;
    p.y = y;

    return p.transform(plots.screenCTM().inverse());
  }

  public static svgToDOM(event) {
    const plots = SVG('plots');
    const p = new SVG.Point();

    if (event.touches !== undefined) {
      p.x = (event.touches as TouchList)[0].clientX;
      p.y = (event.touches as TouchList)[0].clientY;
    } else {
      p.x = event.x;
      p.y = event.y;
    }

    return p.transform(plots.screenCTM());
  }

  public static svgCoordsToDOMCoords(x: number, y: number) {
    const plots = SVG('plots');
    const p = new SVG.Point();
    p.x = x;
    p.y = y;
    return p.transform(plots.screenCTM());
  }

  public static isComputationalSub(name: string) {
    switch (name) {
      case 'SUB_BRICK':
        return true;
      case 'SUB_STONE':
        return true;
      case 'SUB_BLOCK':
        return true;
    }
    return false;
  }

  public static getTempPlotSVG() {
    return SVG('plots').svg('temp_' + String(new Guid()));
  }
}
