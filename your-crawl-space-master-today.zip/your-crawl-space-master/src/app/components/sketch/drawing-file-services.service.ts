import { Injectable, Output } from '@angular/core';
import {
  DrawingModel,
  IconsAndPlots,
  IndexDBDrawingResult,
  SerialLineAndPoints,
} from '../../storage/models';
import { SketchService } from './sketch.service';
import { DataStorageService } from '../../storage/data-storage.service';
import { EstimateService } from '../../services/estimate/estimate.service';
import { IconEnums } from './enums';
import { AlertController, ToastController } from '@ionic/angular';
import * as SVG from 'svg.js';
import { Guid } from '../../util/utils';
import { BehaviorSubject } from 'rxjs';
import * as _ from 'lodash';
import Mode = IconEnums.Mode;

@Injectable()
export class DrawingFileServicesService {
  @Output()
  storedDrawingsBS: BehaviorSubject<Array<IndexDBDrawingResult>> =
    new BehaviorSubject<Array<IndexDBDrawingResult>>([]);
  storedDrawings = this.storedDrawingsBS.asObservable();
  totalStoredDrawings = 0;
  newSketchDefaultName = 'New YCS Sketch';
  currentDrawingDisplayName = new BehaviorSubject<string>(
    'No drawing loaded...'
  );
  activeDrawingId = null;

  constructor(
    private sketchService: SketchService,
    private datastore: DataStorageService,
    private estimateService: EstimateService,
    private alertController: AlertController,
    private toastController: ToastController,
  ) {
    this.refreshDrawingsList((drawings) => {
      this.storedDrawingsBS.next(drawings);
      this.totalStoredDrawings = drawings.length;
    });
  }

  loadDrawing(drawing: DrawingModel, gotoSketch = true) {
    const dp: DOMParser = new DOMParser();

    // reset the plots and icons and inject the SVG into the elements
    const instance = this.sketchService.sketchComponentInstance;

    instance.confirmedGridReset();

    instance.loadIcons(drawing.svgDocument.iconRoot);
    instance.loadPlots(drawing.svgDocument.plotsRoot);
    // set the instance drawing id
    instance.drawingId = drawing.drawingId;

    // reconstitute the SVG.Line, SVG.Circle and SVG.Path objects needed for this array
    drawing.lineArray.forEach((line: SerialLineAndPoints) => {
      const l = this.reconstituteLine(line.line, dp);
      const p1 = this.reconstitutePoint(line.points[0], dp);
      const p2 = this.reconstitutePoint(line.points[1], dp);
      const subPath = this.reconstituteSubPath(line.substratePath, dp);

      instance.sketchState.lineArray.push({
        line: l,
        points: [p1, p2],
        substratePath: subPath,
        substratePattern: line.substratePattern,
        isComputationalSub: line.isComputationalSub === 'true',
      });
    });

    // set the currentid in the database
    this.datastore.setCurrentId(drawing.drawingId);

    this.estimateService.estimate();

    if (this.sketchService.currentMode !== Mode.ADJUST) {
      instance.toggleEndpoints(false);
    }

    this.currentDrawingDisplayName.next(drawing.display);

    this.refreshDrawingsList();
    this.activeDrawingId = drawing.drawingId;

    if (gotoSketch) {
      this.sketchService.ycsTabs.select('tab1');
    }

    // this._printDataService.loadPrintArea(drawing.printAreaRect);
  }

  deleteDrawing(drawingId: string) {
    this.presentDeleteConfirm(drawingId);
  }

  async presentDeleteConfirm(drawingId) {
    const alert = await this.alertController.create({
      header: 'DELETE!',
      message:
        'Are you sure you want to DELETE this sketch? The action cannot be undone.',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {},
        },
        {
          text: 'Okay',
          handler: () => {
            this.deleteConfirmed(drawingId);
          },
        },
      ],
    });

    await alert.present();
  }

  async presentNewDrawingConfirm() {
    const alert = await this.alertController.create({
      header: 'NEW!',
      message:
        'This action will erase any unsaved changes in your current drawing. Are you sure you want to create a NEW drawing?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Cancelled grid reset');
          },
        },
        {
          text: 'Okay',
          handler: () => {
            this.confirmedCreateNewDrawing();
          },
        },
      ],
    });

    await alert.present();
  }

  saveActiveDrawing() {
    const date = new Date();

    const instance = this.sketchService.sketchComponentInstance;
    const iconsAndPlots: IconsAndPlots = instance.getPlotsAndSIconsSVG();
    const lineArray = instance.sketchService.getLineArray();

    const oSerializer = new XMLSerializer();
    const linesSerialized: Array<SerialLineAndPoints> = [];

    lineArray.forEach((line) => {
      const l = oSerializer.serializeToString(line.line.node);
      const p = [];
      p.push(oSerializer.serializeToString(line.points[0].node));
      p.push(oSerializer.serializeToString(line.points[1].node));
      const subPath = oSerializer.serializeToString(line.substratePath.node);

      linesSerialized.push({
        line: l,
        points: p,
        substratePath: subPath,
        substratePattern: line.substratePattern,
        isComputationalSub: line.isComputationalSub.toString(),
      });
    });

    let drawingName = this.newSketchDefaultName;

    // check if the drawing already exists
    // Keep the existing display name if it does
    this.datastore.getDrawingById(instance.drawingId, (d) => {
      if (d) {
        drawingName = d.display;
      }

      const drawing: DrawingModel = {
        drawingId: instance.drawingId,
        lastModified: date,
        display: drawingName,
        lineArray: linesSerialized,
        svgDocument: {
          plotsRoot: iconsAndPlots.plotsRoot,
          iconRoot: iconsAndPlots.iconRoot,
        },
      };

      this.datastore.saveDrawing(drawing.drawingId, drawing, () => {
        this.presentToast('Your drawing has been saved.');
        this.refreshDrawingsList();
      });

      this.activeDrawingId = drawing.drawingId;
    });
  }

  refreshDrawingsList(callback?) {
    try {
      this.datastore.getAllDrawings((drawings) => {
        if (callback) {
          callback(this.sortDrawings(drawings));
          return;
        }

        this.storedDrawingsBS.next(this.sortDrawings(drawings));
      });
    } catch (e) {
      console.log(e);
    }
  }

  async presentToast(msg: string) {
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000,
      position: 'middle',
    });
    toast.present();
  }

  confirmedCreateNewDrawing() {
    const instance = this.sketchService.sketchComponentInstance;
    instance.confirmedGridReset();
    instance.drawingId = Guid.newGuid();

    const drawing: DrawingModel = this.getEmptyDrawingObject(
      instance.drawingId
    );

    this.datastore.initializeStores(drawing);
    this.refreshDrawingsList();
    this.activeDrawingId = drawing.drawingId;
  }

  // If there are no drawings in the database on load, this is called to create one
  createFirstRunDrawing() {
    if (this.totalStoredDrawings === 0) {
      const drawing: DrawingModel = this.getEmptyDrawingObject();
      this.datastore.initializeStores(drawing);
      this.currentDrawingDisplayName.next('New YCS Sketch');
      this.datastore.saveDrawing(drawing.drawingId, drawing, () => {
        this.refreshDrawingsList();
        this.loadDrawing(drawing);
      });
      this.sketchService.sketchComponentInstance.setSubstrate('SUB_BRICK', 18);
    }
  }

  // Currently only lastModified DESC
  private sortDrawings(toSort: Array<IndexDBDrawingResult>) {
    return _.orderBy(toSort, (result) => result.v.lastModified, ['desc']);
  }

  // r="10" cx="204" cy="348" fill="#ff4a00" class="sketch-point" opacity="0"/>
  private reconstitutePoint(circleSvgString: string, dp: DOMParser) {
    const tempP1 = dp.parseFromString(circleSvgString, 'image/svg+xml');
    const item = tempP1.getElementsByTagName('circle').item(0);
    const p = SVG('plots').select('circle#' + item.id)['members'];

    // TODO: I only really need to store JUST the id of the point
    // Add this to the refactor list
    return p[0];
  }

  // class="sketch-line" naked-id="ycs_5a9e5340-cb48-472d-a55f-97b6268f7830"/>
  private reconstituteLine(lineSvgString: string, dp: DOMParser) {
    const tempLine = dp.parseFromString(lineSvgString, 'image/svg+xml');
    const item = tempLine.getElementsByTagName('line').item(0);
    const line = SVG('plots').select('line#' + item.id)['members'];

    return line[0];
  }

  // stroke-width="18" stroke-linecap="round" naked-id="SvgjsLine1280" class="substrate"/>"
  private reconstituteSubPath(pathSvgString: string, dp: DOMParser) {
    const tempPath = dp.parseFromString(pathSvgString, 'image/svg+xml');
    const item = tempPath.getElementsByTagName('path').item(0);
    const path = SVG('plots').select('path#' + item.id)['members'];

    return path[0];
  }

  private deleteConfirmed(drawingId) {
    // is this an active drawing?
    if (this.activeDrawingId !== drawingId) {
      this.datastore.deleteDrawing(drawingId, () => {});
    } else if (this.activeDrawingId === drawingId) {
      // the active drawing is being deleted
      this.datastore.deleteDrawing(drawingId, () => {
        this.datastore.getAllDrawings((drawings: IndexDBDrawingResult[]) => {
          if (drawings.length > 0) {
            const sorted = this.sortDrawings(drawings);
            this.loadDrawing(sorted[0].v, false);
          } else {
            // it was the last file in the list. Cleanup the grid space
            this.sketchService.sketchComponentInstance.confirmedGridReset();
            this.totalStoredDrawings = 0;
          }
        });
      });
    }
    this.refreshDrawingsList();
  }

  private getEmptyDrawingObject(drawingId?: any): DrawingModel {
    return {
      drawingId: drawingId === undefined ? Guid.newGuid() : drawingId,
      lastModified: new Date(),
      display: this.newSketchDefaultName,
      lineArray: [],
      svgDocument: {
        plotsRoot: '',
        iconRoot: '',
      },
      // printAreaRect: {
      //     x: 0,
      //     y: 0,
      //     height: this._printDataService.defaultHeight,
      //     width: this._printDataService.defaultWidth
      // }
    };
  }
}
