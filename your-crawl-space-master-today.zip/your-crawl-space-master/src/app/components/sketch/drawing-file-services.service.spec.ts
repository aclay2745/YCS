import { TestBed } from '@angular/core/testing';

import { DrawingFileServicesService } from './drawing-file-services.service';

describe('DrawingFileServicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DrawingFileServicesService = TestBed.get(DrawingFileServicesService);
    expect(service).toBeTruthy();
  });
});
