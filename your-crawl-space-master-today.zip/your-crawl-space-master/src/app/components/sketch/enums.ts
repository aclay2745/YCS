export namespace IconEnums {
  export enum Mode {
    DRAW,
    ERASE,
    ADJUST,
    ICON,
    ZOOM,
    ICON_ADJUST,
    PRINT_AREA,
  }

  export enum DamageIcon {
    DMG_MOLD,
    DMG_WATER,
    DMG_STANDING_WATER,
    DMG_RODENT,
    DMG_TERMITE_ACTIVE,
    DMG_TERMITE_INACTIVE,
    DMG_FUNGUS_ACTIVE,
    DMG_FUNGUS_INACTIVE,
  }

  export enum EquipmentIcon {
    EQP_SERVICE_MONITOR,
    EQP_DEHUMIDIFIER,
    EQP_SUMP_PUMP,
    EQP_HVAC,
    EQP_WATER_HEATER,
  }

  export enum StructureIcon {
    STR_ACCESS_DOOR,
    STR_FENCE_GATE,
    STR_VENT,
    STR_VENT_HALF,
    STR_DRAIN,
    STR_PIER_24_36,
    STR_PIER_16_16,
    STR_PIER_8_16,
  }

  export enum ItemDescriptions {
    DMG_MOLD = 'Damage - Mold',
    DMG_WATER = 'Damage - Water',
    DMG_STANDING_WATER = 'Damage - Standing Water',
    DMG_RODENT = 'Damage - Rodent',
    DMG_TERMITE_ACTIVE = 'Damage - Active Termites',
    DMG_TERMITE_INACTIVE = 'Damage - Inactive Termites',
    DMG_FUNGUS_ACTIVE = 'Damage - Active Fungus',
    DMG_FUNGUS_INACTIVE = 'Damage - Inactive Fungus',
    EQP_SERVICE_MONITOR = 'Equipment - Service Monitor',
    EQP_DEHUMIDIFIER = 'Equipment - Dehumidifier',
    EQP_SUMP_PUMP = 'Equipment - Sump Pump',
    EQP_HVAC = 'Equipment - HVAC',
    EQP_WATER_HEATER = 'Equipment - Water Heater',
    STR_ACCESS_DOOR = 'Structure - Access Door',
    STR_FENCE_GATE = 'Structure - Fence Gate',
    STR_VENT = 'Structure - Vent',
    STR_VENT_HALF = 'Structure - Vent',
    STR_DRAIN = 'Structure - Drain',
    STR_PIER_24_36 = 'Draw - 24x36 Pier',
    STR_PIER_16_16 = 'Structure - Support Pier',
    STR_PIER_8_16 = 'Draw - 8x16 Pier',
    ENV_DOG = 'Environment - Dog or Animal',
    ENV_GRADE_ARROW = 'Environment - Grade Arrow',
    SUB_BLOCK = 'Draw - Block',
    SUB_BRICK = 'Draw - Brick',
    SUB_STONE = 'Draw - Stone',
    SUB_FENCE = 'Structure - Fence',
    SUB_DRAINLINE = 'Equipment - Drainline',
    SUB_PUMPLINE = 'Equipment - Pumpline',
    SUB_DUCTLINE = 'Equipment - Ductline',
    UI_ENDPOINT_EDIT = 'Draw - Endpoint Edit',
    UI_ERASE = 'Draw - Eraser',
    UI_TRASH = 'Draw - Erase All',
    UI_ZOOM = 'Pan and Zoom',
    PRINT_AREA = 'Print Area Tool',
    PRINT_AREA_ZOOM = 'Print Area Tool - Pan / Zoom',
    PRINT_AREA_HIGHLIGHT = 'Print Area Tool - Highlight',
  }

  export enum EnvironmentIcon {
    ENV_DOG,
    ENV_GRADE_ARROW,
  }

  export enum DrawStyle {
    BLOCK,
    LINE,
  }

  export function getName(enumObj: any): string {
    for (const name in IconEnums) {
      if (IconEnums[name] === enumObj && IconEnums.hasOwnProperty(name)) {
        return name;
      }
    }
    return undefined;
  }
}
