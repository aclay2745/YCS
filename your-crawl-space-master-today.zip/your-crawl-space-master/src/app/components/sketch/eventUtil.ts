export class EventUtil {
  public static getZoomPointFromEvent(event, grid) {
    const point = { x: 0, y: 0 };

    if (event.touches !== undefined) {
      point.x = (event.touches as TouchList)[0].clientX + Number(grid.style.left);
      point.y = (event.touches as TouchList)[0].clientY + Number(grid.style.top);
    } else {
      point.x = event.offsetX + Number(grid.style.left);
      point.y = event.offsetY + Number(grid.style.top);
    }

    return point;
  }

  public static getPointFromEvent(event) {
    const point = { x: 0, y: 0 };

    if (event.touches !== undefined) {
      point.x = (event.touches as TouchList)[0].clientX;
      point.y = (event.touches as TouchList)[0].clientY;
    } else {
      point.x = event.x;
      point.y = event.y;
    }

    return point;
  }
}
