import * as SVG from 'svg.js';

export interface Listeners {
  onEventDown: EventListenerOrEventListenerObject;
  onEventUp: EventListenerOrEventListenerObject;
  onEventMove: EventListenerOrEventListenerObject;
}

export interface SketchLine {
  line: SVG.Line;
  points: SketchPoint;
}

export interface SketchPoint {
  startPoint: SVG.Circle;
  endPoint: SVG.Circle;
}

export interface ITransform {
  iconAndFrame: IconAndFrame;
  highlightAndHandles: HighlightAndHandles;
  activeClassName: string;
}

export interface IconAndFrame {
  icon: SVG.Element;
  frame: SVG.Element;
}

export interface HighlightAndHandles {
  highlight: any;
  handles: {
    left: SVG.G;
    right: SVG.G;
  };
}

export interface RotationValues {
  lastRot: number;
  lastX: number;
  lastY: number;
}

export interface PolyPointCoord {
  x: number;
  y: number;
}

export interface PolyPointLineCoords {
  start: PolyPointCoord;
  end: PolyPointCoord;
}
