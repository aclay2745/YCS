import { SketchComponentUtil } from './lib/sketch.component.util';
import { Guid } from '../../util/utils';
import * as SVG from 'svg.js';
import { IconEnums } from './enums';
import * as _ from 'lodash';
import { Injectable } from '@angular/core';
import {
  HighlightAndHandles,
  IconAndFrame,
  ITransform,
  RotationValues,
} from './models';
import { IconEventModel, IconImageModel } from '../../storage/models';
import IssueIcon = IconEnums.DamageIcon;
import EquipmentIcon = IconEnums.EquipmentIcon;
import StructureIcon = IconEnums.StructureIcon;
import EnvironmentIcon = IconEnums.EnvironmentIcon;
import { IconSvgService } from '../../services/icon-access-service/icon-svg.service';

/* This class uses a mixture of SVG.js and direct DOM manipulation.
 * Sometimes SVG.js works well, other times, well it did not...so DOM.
 * */

@Injectable({
  providedIn: 'root',
})
export class IconFactory {
  /*
    Retrieves the icon element frame from the event x/y i.e. filters for specific elements at the touch point
  */
  public static getIconFrameFromPoint(event) {
    return document
      .elementsFromPoint(event.x, event.y)
      .filter(
        (e) =>
          e.classList.contains('issue-icon-frame') ||
          e.classList.contains('icon-menu') ||
          e.classList.contains('rotate-arrow') ||
          e.classList.contains('icon-highlight')
      ) as Array<Element>;
  }

  public static getIconMenuItemFromPoint(event) {
    return document
      .elementsFromPoint(event.x, event.y)
      .filter(
        (e) =>
          e.classList.contains('icon-menu') &&
          (e.classList.contains('_camera') ||
            e.classList.contains('_trash') ||
            e.classList.contains('_hand') ||
            e.classList.contains('_stored_image'))
      ) as Array<Element>;
  }

  public static deleteIconContainer(id: string) {
    _.each(SVG.select('#' + id)['members'], (c) => {
      c.remove();
    });
  }

  public static getIconAndFrameById(id): IconAndFrame {
    const icon: SVG.Set = SVG.select('#' + id + '_icon')['members'];
    const frame: SVG.Set = SVG.select('#' + id + '_icon_frame')['members'];
    return {
      icon: icon[0],
      frame: frame[0],
    };
  }

  public static getHighlightAndHandlesById(id): HighlightAndHandles {
    const highlight: SVG.Set = SVG.select('#' + id + '_icon_highlight')[
      'members'
    ];
    const left: SVG.Set = SVG.select('#' + id + '_rotate_icon_left')['members'];
    const right: SVG.Set = SVG.select('#' + id + '_rotate_icon_right')[
      'members'
    ];

    return {
      highlight: highlight[0],
      handles: {
        left: left[0],
        right: right[0],
      },
    };
  }

  public static getVisibleTransformControls() {
    const controls: SVG.Set = SVG.select('rect.icon-highlight')['members'];
    return controls;
  }

  public static moveIcon(transObj: ITransform, event) {
    let x;
    let y;

    const iconContainer = SVG(transObj.iconAndFrame.frame.attr('naked-id'));
    const isPier = transObj.iconAndFrame.frame.attr('is-pier');

    if (isPier === 'false') {
      x = Math.round(event.x / 12) * 12 - 6;
      y = Math.round(event.y / 12) * 12;
      iconContainer.attr('x', String(x - 48));
      iconContainer.attr('y', String(y - 24));
    } else {
      // It's a pier
      x = Math.round(event.x / 12) * 12 + 1;
      y = Math.round(event.y / 12) * 12 + 1;
      iconContainer.attr('x', String(x - 12));
      iconContainer.attr('y', String(y - 12));
    }
  }

  public static hideAllIconMenus() {
    _.each(SketchComponentUtil.getAllIconMenus(), (iconMenu: SVG.Element) => {
      iconMenu.remove();
    });

    _.each(
      SketchComponentUtil.getAllIconMenuItemIcons(),
      (iconMenuItemIcon: SVG.Element) => {
        iconMenuItemIcon.remove();
      }
    );
  }

  public static removeAllIconHighlights() {
    _.each(
      SVG.select('rect.icon-highlight')['members'],
      (highlight: SVG.Element) => {
        highlight.remove();
      }
    );

    _.each(SVG.select('.rotate-arrow')['members'], (handle: SVG.Element) => {
      handle.remove();
    });
  }

  /*
    Displays the icon pop up menu
     */
  public static generateIconMenuItem(
    svg: HTMLElement,
    nakedId: string,
    x: number,
    y: number,
    position: number
  ) {
    let xOffset;
    let yOffset;
    let itemClass;
    let icon;

    switch (position) {
      case 1:
        xOffset = 80;
        yOffset = -34;
        itemClass = '_camera';
        icon = 'UI_CAMERA_SMALL';
        break;
      case 2:
        xOffset = 80;
        yOffset = 3;
        itemClass = '_hand';
        icon = 'UI_HAND_SMALL';
        break;
      case 3:
        xOffset = 80;
        yOffset = 40;
        itemClass = '_trash';
        icon = 'UI_TRASH_SMALL';
        break;
      case 4:
        xOffset = -12;
        yOffset = 3;
        itemClass = '_stored_image';
        icon = 'UI_GALLERY_SMALL';
        break;
    }

    const item = IconFactory.createMenuItemBubble(
      nakedId,
      x,
      xOffset,
      y,
      yOffset,
      itemClass
    );
    const itemIcon = IconFactory.createMenuItemIcon(
      icon,
      nakedId,
      x,
      xOffset,
      y,
      yOffset
    );

    svg.appendChild(item);
    svg.appendChild(itemIcon);
  }

  /*
    Creates the bubble for an icon menu item
     */
  public static createMenuItemBubble(
    nakedId,
    x,
    xOffset,
    y,
    yOffset,
    itemClass
  ): SVGUseElement {
    const item = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    item.setAttributeNS(
      'http://www.w3.org/1999/xlink',
      'xlink:href',
      '../../assets/ICON_MENU.svg#ICON_MENU'
    );

    // Create menu item
    item.setAttribute('id', nakedId + '_icon_menu');
    item.setAttribute('naked-id', nakedId);
    item.setAttribute('x', String(x + xOffset));
    item.setAttribute('y', String(y + yOffset));
    item.setAttribute('class', 'icon-menu ' + itemClass);
    return item;
  }

  /*
    Creates the icon for an icon menu item
     */
  public static createMenuItemIcon(icon, nakedId, x, xOffset, y, yOffset) {
    const itemIcon = document.createElementNS(
      'http://www.w3.org/2000/svg',
      'use'
    );
    itemIcon.setAttributeNS(
      'http://www.w3.org/1999/xlink',
      'xlink:href',
      '../../assets/' + icon + '.svg#' + icon
    );

    // Create menu item icon
    itemIcon.setAttribute('id', nakedId + '_icon_menu_item_icon');
    itemIcon.setAttribute('naked-id', nakedId);
    itemIcon.setAttribute('x', String(x + xOffset + 6));
    itemIcon.setAttribute('y', String(y + yOffset + 7));
    itemIcon.setAttribute('class', 'icon-menu-icon');
    return itemIcon;
  }

  /*
    Displays the icon menu
     */
  public static showIconMenu(
    svg: HTMLElement,
    nakedId: string,
    x: number,
    y: number
  ) {
    // close other menus before opening a new one
    IconFactory.hideAllIconMenus();
    IconFactory.removeAllIconHighlights();
    IconFactory.generateIconMenuItem(svg, nakedId, x, y, 1);
    IconFactory.generateIconMenuItem(svg, nakedId, x, y, 2);
    IconFactory.generateIconMenuItem(svg, nakedId, x, y, 3);

    IconFactory.getImage(nakedId, (image) => {
      if (image) {
        IconFactory.generateIconMenuItem(svg, nakedId, x, y, 4);
      }
    });
  }

  // look up the associated image in the DB for this icon instance
  // TODO: This may be in the wrong place
  public static getImage(nakedId, callback) {
    window['ldb'].get(
      'id',
      (currentId) => {
        window['ldb'].get(
          currentId,
          (store) => {
            const hasImage = _.find(
              store,
              (image: IconImageModel) => image.imageId === nakedId
            );
            callback(hasImage, store, currentId);
          },
          'i'
        );
      },
      'c'
    );
  }

  /*
    Gets the icon associated with the current operation
     */
  public static _getIcon(eventModel: IconEventModel) {
    let icon;
    switch (eventModel.markerIconTypeSubject.value) {
      case 'DamageIcon':
        icon = IssueIcon[eventModel.markerIconSubject.value];
        break;
      case 'EquipmentIcon':
        icon = EquipmentIcon[eventModel.markerIconSubject.value];
        break;
      case 'StructureIcon':
        icon = StructureIcon[eventModel.markerIconSubject.value];
        break;
      case 'EnvironmentIcon':
        icon = EnvironmentIcon[eventModel.markerIconSubject.value];
        break;
    }

    return icon;
  }

  public static getIcon(
    icon: string,
    iconElement,
    iconSvg,
    iconFrameElement,
    iconSvgService,
    guid,
    iconSvgContainer,
    svgP
  ) {
    const isVent = icon.search('STR_VENT_HALF') === 0;

    if (isVent) {
      iconElement.native().innerHTML = iconSvg;
      iconFrameElement.native().innerHTML = iconSvgService.getIconFrameHalf();
      iconElement.attr('is-vent', 'true');
    } else {
      iconElement.native().innerHTML = iconSvg;
      iconFrameElement.native().innerHTML = iconSvgService.getIconFrame();
      iconElement.attr('is-vent', 'false');
    }

    // Create the frame
    iconFrameElement.attr('id', guid + '_icon_frame');
    iconFrameElement.attr('naked-id', guid);
    iconFrameElement.attr('x', 30);
    iconFrameElement.attr('y', 0);
    iconFrameElement.attr('class', 'issue-icon-frame');
    iconFrameElement.attr('is-pier', 'false');

    // create the icon
    iconElement.attr('id', guid + '_icon');
    iconElement.attr('naked-id', guid);
    iconElement.attr('x', 38);
    iconElement.attr('y', 8);
    iconElement.attr('class', 'issue-icon');

    iconSvgContainer.attr('x', Math.round(svgP.x / 12) * 12 - 30);
    iconSvgContainer.attr('y', Math.round(svgP.y / 12) * 12);
  }

  /*
    Handles icon placement / menu events
     */ // TODO: This method is way too fat. Refactor
  public static iconEvent(
    iconSvgService: IconSvgService,
    eventModel: IconEventModel,
    imgViewerCallback
  ): number | IconImageModel {
    const svgP = SketchComponentUtil.domToSVG(event);
    const svg = SVG('icons');

    // Check to see if we are over another icon or icon frame
    // don't want to stack them
    const ele = IconFactory.getIconFrameFromPoint(event);

    // is the transform feature active?
    const controls = IconFactory.getVisibleTransformControls();

    if (_.size(controls) > 0) {
      return 1;
    }

    const icon = IconFactory._getIcon(eventModel) as string;
    const isPier = icon.search('STR_PIER_') === 0;
    const size816 = icon.search('STR_PIER_8_16') === 0;
    const size1616 = icon.search('STR_PIER_16_16') === 0;

    const iconSvg = iconSvgService.getIconSVG(icon);

    if (ele.length === 0) {
      // Any touch / click that isn't a menu should close any that are currently open
      IconFactory.hideAllIconMenus();

      // also get rid of any highlights
      IconFactory.removeAllIconHighlights();

      const guid = 'ycs_' + String(Guid.newGuid());

      const iconSvgContainer = IconFactory.getIconSvgContainer(svg, guid);

      const containerGroup = iconSvgContainer.group();
      containerGroup.attr('id', guid + '_container_group');

      const iconElement = iconSvgContainer.nested();
      const iconFrameElement = iconSvgContainer.nested();

      if (isPier) {
        // Pier icons
        IconFactory.createPier(
          iconElement,
          iconSvg,
          iconFrameElement,
          iconSvgService,
          iconSvgContainer,
          guid,
          eventModel,
          svgP
        );
      } else {
        // Standard damage, structure, environment icon
        IconFactory.getIcon(
          icon,
          iconElement,
          iconSvg,
          iconFrameElement,
          iconSvgService,
          guid,
          iconSvgContainer,
          svgP
        );
      }

      containerGroup.add(iconFrameElement);
      containerGroup.add(iconElement);
      iconSvgContainer.add(containerGroup);

      svg.add(iconSvgContainer);
    } else if (
      ele[0].parentElement.parentElement.parentElement.attributes.getNamedItem(
        'id'
      ).value
    ) {
      let nakedId;
      if (ele[0].tagName === 'use') {
        nakedId = ele[0].attributes.getNamedItem('naked-id').value;
      } else {
        nakedId =
          ele[0].parentElement.parentElement.parentElement.attributes.getNamedItem(
            'naked-id'
          ).value;
      }

      // check if this guy has at least one open menu already
      const currentMenu = SVG.select('use.icon-menu#' + nakedId + '_icon_menu')[
        'members'
      ];

      if (currentMenu[0] === undefined) {
        // need the frame to get its coords
        // open the icon's menu
        const iconSvgContainer = SVG(nakedId);
        IconFactory.showIconMenu(
          svg.native(),
          nakedId,
          Number(iconSvgContainer.attr('x') + 2),
          Number(iconSvgContainer.attr('y') + 2)
        );
      } else if (currentMenu[0]) {
        try {
          // at this point the icon sub menu is visible
          // none of the other conditions apply so
          // I'm going to presume the user has clicked
          // a menu item
          const menuItem = IconFactory.getIconMenuItemFromPoint(event);

          const menuClass = menuItem[0].className['baseVal'];

          switch (menuClass) {
            case 'icon-menu _camera':
              eventModel.forStorage.imageId =
                menuItem[0].getAttribute('naked-id');
              eventModel.forStorage.iconType =
                eventModel.markerIconTypeSubject.value;
              eventModel.forStorage.iconName =
                eventModel.markerIconSubject.value.toString();
              eventModel.cameraService.takePicture(eventModel.forStorage);
              break;
            case 'icon-menu _hand':
              IconFactory.activateTransform(nakedId, svg, svgP);
              return 1; // Sooooooooper hacky because ...deadlines...
            case 'icon-menu _trash':
              IconFactory.getImage(nakedId, (image, store, drawingId) => {
                if (image) {
                  const newStore = _.pull(store, image);
                  window['ldb'].set(drawingId, newStore, 'i');
                }
              });

              IconFactory.deleteIconContainer(nakedId);

              if (isPier) {
                // lower the pier count
                const newSize =
                  eventModel.estimateService.pierCount1616.getValue() - 1;
                eventModel.estimateService.pierCount1616.next(newSize);
                eventModel.estimateService.estimate();
              }
              IconFactory.removeAllIconHighlights();
              break;
            case 'icon-menu _stored_image':
              IconFactory.getImage(nakedId, (image, store, drawingId) => {
                if (image) {
                  imgViewerCallback(image);
                }
              });
              break;
          }
        } catch (e) {
          console.log(e);
        }

        IconFactory.hideAllIconMenus();
      } else {
        IconFactory.removeAllIconHighlights();
      }
    }
    return 0;
  }

  public static getIconSvgContainer(svg, guid) {
    const iconSvgContainer = svg.nested();
    iconSvgContainer.attr('width', '108px');
    iconSvgContainer.attr('height', '56px');
    iconSvgContainer.attr('id', guid);
    iconSvgContainer.attr('class', 'icon-container');
    iconSvgContainer.attr('pointer-events', 'all');

    return iconSvgContainer;
  }

  public static createPier(
    iconElement,
    iconSvg,
    iconFrameElement,
    iconSvgService,
    iconSvgContainer,
    guid,
    eventModel,
    svgP
  ) {
    iconElement.native().innerHTML = iconSvg;

    iconFrameElement.native().innerHTML = iconSvgService.getIconFrame();

    // Create the frame
    iconFrameElement.attr('id', guid + '_icon_frame');
    iconFrameElement.attr('naked-id', guid);
    iconFrameElement.attr('x', 0);
    iconFrameElement.attr('y', 0);
    iconFrameElement.attr('class', 'issue-icon-frame');
    iconFrameElement.attr('is-pier', 'true');

    // create the icon
    iconElement.attr('id', guid + '_icon');
    iconElement.attr('naked-id', guid);

    // update the pier count
    const newSize = eventModel.estimateService.pierCount1616.getValue() + 1;
    eventModel.estimateService.pierCount1616.next(newSize);

    iconElement.attr('y', 0);
    iconElement.attr('x', 0);
    iconElement.attr('class', 'issue-icon');

    iconSvgContainer.attr('x', Math.round(svgP.x / 12) * 12 + 1);
    iconSvgContainer.attr('y', Math.round(svgP.y / 12) * 12 + 1);

    eventModel.estimateService.estimate();
  }

  /*
   * Displays the highlight for grabbing and moving an icon
   *
   * */
  public static activateTransform(id, svg, svgP) {
    // Create a group and add the icon and frame to the group
    // Then add that group to the iconSvgContainer
    const iconAndFrame = IconFactory.getIconAndFrameById(id);
    const group = SVG(id).group();
    const bbox = iconAndFrame.frame.bbox();
    const highlightRectangle = new SVG.Rect();

    const iconName = iconAndFrame.icon.node.children.item(0).id;

    if (iconName === 'STR_PIER_16_16') {
      highlightRectangle.attr('x', String(bbox.x));
      highlightRectangle.attr('y', String(bbox.y));
    } else {
      highlightRectangle.attr('x', String(bbox.x + 36));
      highlightRectangle.attr('y', String(bbox.y + 6));
    }

    highlightRectangle.attr('width', String(bbox.width - 12));
    highlightRectangle.attr('height', String(bbox.height - 12));
    highlightRectangle.attr('fill', 'd1f2ff');
    highlightRectangle.attr('fill-opacity', '0.5');
    highlightRectangle.attr('stroke', '#fdff4b');
    highlightRectangle.attr('stroke-width', '8');
    highlightRectangle.attr('stroke-opacity', '1');
    highlightRectangle.attr('id', id + '_icon_highlight');
    highlightRectangle.attr('naked-id', id);
    highlightRectangle.attr('class', 'icon-highlight');

    if (iconName === 'STR_VENT' || iconName === 'ENV_GRADE_ARROW') {
      const arrowPathLeft = IconFactory.addRotateIcon(
        svg,
        id,
        '_rotate_icon_left',
        0,
        0
      );
      const arrowPathRight = IconFactory.addRotateIcon(
        svg,
        id,
        '_rotate_icon_right',
        78,
        0,
        1
      );
      group.add(arrowPathLeft);
      group.add(arrowPathRight);
      arrowPathLeft.translate(-6, 0);
      arrowPathRight.translate(114, 0);
    }

    group.add(highlightRectangle);
    SVG(id).add(group);
  }

  private static addRotateIcon(svg, id, idAppend, x, y, flag?) {
    const d =
      'M22.912,46.394C11.932,39.589 -0.738,16.074 12.402,0.21L32.798,0.142C19.954,17.046 21.459,34.913 28.902,' +
      '40.716C30.996,38.217 32.785,35.397 34.258,32.246L36.93,54.062L13.975,51.455C17.259,50.088 20.242,48.405 22.912,46.394Z';

    const path = new SVG.Path();
    path.attr('d', d);
    path.attr('fill', 'rgb(0,4,255)');
    path.attr('class', 'rotate-arrow');
    path.attr('opacity', '0.5');
    path.attr('id', id + idAppend);
    path.attr('naked-id', id);

    if (flag) {
      path.matrix(-1, 0, 0, 1, 37.5939, 0.266836);
      path.addClass('rotate-arrow-right');
    } else {
      path.matrix(1, 0, 0, 1, -6.13723, 0.266836);
      path.addClass('rotate-arrow-left');
    }

    return path;
  }

  /*public static rotateIcon(transObj: ITransform, event, rotVals: RotationValues) { // TODO: This is buggie as hell and needs updating

        const currentX = event.x;
        const currentY = event.y;
        const bbox = transObj.iconAndFrame.frame.bbox();
        let radians = 0;

        if (rotVals.lastX > currentX || rotVals.lastY > currentY) {
            rotVals.lastRot++;
        }

        if (rotVals.lastX < currentX || rotVals.lastY < currentY) {
            rotVals.lastRot--;
        }
        radians = Math.atan2(event.y, event.x);

        // const radians = Math.atan2(event.y, event.x );

        const degree = radians * (180 / Math.PI) + rotVals.lastRot;

        transObj.iconAndFrame.frame.rotate(degree, bbox.cx, bbox.cy);
        transObj.iconAndFrame.icon.rotate(degree, bbox.cx, bbox.cy);
        transObj.highlightAndHandles.highlight.rotate(degree, bbox.cx, bbox.cy);
        transObj.highlightAndHandles.handles.topLeft.rotate(degree, bbox.cx, bbox.cy);

        rotVals.lastX = currentX;
        rotVals.lastY = currentY;


        return rotVals;

    }*/

  private static deltaTransformPoint(matrix, point) {
    const dx = point.x * matrix.a + point.y * matrix.c + 0;
    const dy = point.x * matrix.b + point.y * matrix.d + 0;
    return { x: dx, y: dy };
  }

  private static decomposeMatrix(matrix) {
    // calculate delta transform point
    const px = IconFactory.deltaTransformPoint(matrix, { x: 0, y: 1 });
    const py = IconFactory.deltaTransformPoint(matrix, { x: 1, y: 0 });

    // calculate skew
    const skewX = (180 / Math.PI) * Math.atan2(px.y, px.x) - 90;
    const skewY = (180 / Math.PI) * Math.atan2(py.y, py.x);

    return {
      translateX: matrix.e,
      translateY: matrix.f,
      scaleX: Math.sqrt(matrix.a * matrix.a + matrix.b * matrix.b),
      scaleY: Math.sqrt(matrix.c * matrix.c + matrix.d * matrix.d),
      skewX,
      skewY,
      rotation: skewX, // rotation is the same as skew x
    };
  }
}
