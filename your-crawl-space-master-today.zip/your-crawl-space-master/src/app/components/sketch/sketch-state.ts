import { SketchStateModel } from '../../storage/models';

export class SketchState {
  constructor() {}

  public data(): SketchStateModel {
    return {
      activatedPointIndex: -1,
      lineArray: [],
      previewLine: undefined,
      previewLineStartPoint: undefined,
      previewLineEndPoint: undefined,
      startTargetX: undefined,
      startTargetY: undefined,
      startTargetBounds: undefined,
      startElement: undefined,
      lineOpts: {
        stroke: 'black',
        'stroke-width': 1,
      },
      rectOpts: {
        height: 12,
        width: 12,
        stroke: 'darkgrey',
        'stroke-width': 1,
        'stroke-opacity': 0.1,
        fill: 'white',
        'fill-opacity': 0.0,
      },
      gridOpts: {
        grid: 12,
        unitScale: 10,
        rootWidth: 100,
        rootHeight: 100,
      },
      pointOpts: {
        stroke: 'black',
        'stroke-opacity': 0.0,
        'stroke-width': 2,
        fill: 'blue',
        'fill-opacity': 0.1,
        size: 8,
      },
    };
  }
}
