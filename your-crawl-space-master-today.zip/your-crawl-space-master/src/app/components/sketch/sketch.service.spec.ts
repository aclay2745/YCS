import { TestBed } from '@angular/core/testing';

import { SketchService } from './sketch.service';

describe('SketchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SketchService = TestBed.get(SketchService);
    expect(service).toBeTruthy();
  });
});
