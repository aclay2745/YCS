import { Injectable } from '@angular/core';
import * as panzoom from 'panzoom';

@Injectable({
  providedIn: 'root',
})
export class GridZoomService {
  private panZoom;

  zoomPause() {
    this.panZoom.pause();
  }

  zoomResume() {
    this.panZoom.resume();
  }

  zoomSetup(grid: HTMLElement) {
    // @ts-ignore
    this.panZoom = panzoom(grid, {
      maxZoom: 3,
      minZoom: 0.4,
      transformOrigin: { x: 0.5, y: 0.5 },
      bounds: true,
      boundsPadding: 0.25,
      smoothScroll: false,
    });
    this.panZoom.zoomAbs(0, 0, 0.75);
  }

  standardZoom(x = 0, y = 33, scale = 0.4) {
    this.panZoom.moveTo(x, y);
    this.panZoom.zoomAbs(0, 0, scale);
  }
}
