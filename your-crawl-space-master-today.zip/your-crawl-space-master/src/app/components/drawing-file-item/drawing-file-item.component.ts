import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { DrawingModel, IndexDBDrawingResult } from '../../storage/models';
import { SketchService } from '../sketch/sketch.service';
import { DataStorageService } from '../../storage/data-storage.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-drawing-file-item',
  templateUrl: './drawing-file-item.component.html',
  styleUrls: ['./drawing-file-item.component.scss'],
})
export class DrawingFileItemComponent {
  @Input()
  drawing: IndexDBDrawingResult;

  @Output()
  presentToastEmitter: EventEmitter<string> = new EventEmitter<string>();

  @Output()
  refreshDrawingsListEmitter: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  loadDrawingEmitter: EventEmitter<DrawingModel> = new EventEmitter<DrawingModel>();

  @Output()
  deleteDrawingEmitter: EventEmitter<string> = new EventEmitter<string>();

  @Output()
  nameEditModeEmitter: EventEmitter<boolean> = new EventEmitter<boolean>();

  @Input()
  nameEditModeActive: Observable<boolean>;

  @Output()
  updateCurrentDrawingNameEmitter: EventEmitter<string> = new EventEmitter<string>();

  private currentNameEditId: string;

  constructor(
    private sketchService: SketchService,
    private elementRef: ElementRef,
    private datastore: DataStorageService
  ) {}

  isActiveDrawing(drawingId: string) {
    return this.sketchService.sketchComponentInstance.drawingId === drawingId;
  }

  getEditInputElement(drawingId): HTMLInputElement {
    return (
      this.elementRef.nativeElement.querySelector('.editInput_' + drawingId) as HTMLInputElement
    );
  }

  endEdit() {
    this.currentNameEditId = undefined;
    this.nameEditModeEmitter.emit(false);
  }

  isInNameEditMode(drawingId: string) {
    return this.currentNameEditId === drawingId;
  }

  editDrawingName(drawingId: string) {
    this.endEdit();
    this.nameEditModeEmitter.emit(true);
    this.currentNameEditId = drawingId;
  }

  confirmNameUpdate(drawing: DrawingModel) {
    const updateDrawing: DrawingModel = {
      drawingId: drawing.drawingId,
      lastModified: new Date(),
      display: this.getEditInputElement(drawing.drawingId).value,
      lineArray: drawing.lineArray,
      svgDocument: drawing.svgDocument
    };

    this.datastore.saveDrawing(drawing.drawingId, updateDrawing, () => {
      this.presentToastEmitter.emit('Your drawing name has been updated.');
      this.refreshDrawingsListEmitter.emit();
    });

    if (this.isActiveDrawing(drawing.drawingId)) {
      this.updateCurrentDrawingNameEmitter.emit(updateDrawing.display);
    }

    this.endEdit();
    this.refreshDrawingsListEmitter.emit();
  }

  loadDrawing(drawing: DrawingModel) {
    this.loadDrawingEmitter.emit(drawing);
  }

  deleteDrawing(drawingId: string) {
    this.deleteDrawingEmitter.emit(drawingId);
    this.refreshDrawingsListEmitter.emit();
  }
}
