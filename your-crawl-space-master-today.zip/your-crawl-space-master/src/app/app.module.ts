import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ImageModalComponent } from './components/image-modal/image-modal.component';
import { PopoverMenuComponent } from './components/popover-menu/popover-menu.component';

import { CameraService } from './services/camera/camera.service';
import { EstimateService } from './services/estimate/estimate.service';
import { IconSvgService } from './services/icon-access-service/icon-svg.service';
import { YcsPdfService } from './services/ycs-pdf-service/ycs-pdf.service';
import { DataStorageService } from './storage/data-storage.service';
import { ImageModalDataService } from './components/full-size-image-modal/image-modal-data.service';
import { IndexedDbService } from './storage/indexed-db.service';
import { DrawingFileServicesService } from './components/sketch/drawing-file-services.service';

import { SafeHtml } from './components/full-size-image-modal/image-url-sanitizer.pipe';

import { FullSizeImageModalComponent } from './components/full-size-image-modal/full-size-image-modal.component';

import { FileOpener } from '@ionic-native/file-opener/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { Camera } from '@ionic-native/camera/ngx';

import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { AuthConfig, AuthModule } from '@auth0/auth0-angular';
import { domain, clientId, callbackUri } from './auth.config';

const config: AuthConfig = {
  domain,
  clientId,
  redirectUri: callbackUri,
  /* Uncomment the following lines for better support  in browers like Safari where third-party cookies are blocked.
    See https://auth0.com/docs/libraries/auth0-single-page-app-sdk#change-storage-options for risks.
  */
  // cacheLocation: "localstorage",
  // useRefreshTokens: true
};

@NgModule({
  declarations: [
    AppComponent,
    FullSizeImageModalComponent,
    SafeHtml,
    ImageModalComponent,
    PopoverMenuComponent
  ],
  entryComponents: [
    FullSizeImageModalComponent,
    ImageModalComponent,
    PopoverMenuComponent
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    AuthModule.forRoot(config),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    Camera,
    CameraService,
    EstimateService,
    IconSvgService,
    YcsPdfService,
    DataStorageService,
    ImageModalDataService,
    IndexedDbService,
    DrawingFileServicesService,
    FileOpener
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
