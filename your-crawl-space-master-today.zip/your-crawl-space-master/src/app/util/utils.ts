import * as SVG from 'svg.js';
import { v4 as uuidv4 } from 'uuid';


export class Guid {
  static newGuid() {
    return uuidv4();
  }
}

export class PathHelper {
  static getAngleInDegrees(element: SVG.Line) {
    const x1 = element.attr('x1');
    const y1 = element.attr('y1');
    const x2 = element.attr('x2');
    const y2 = element.attr('y2');
    const dY = y2 - y1;
    const dX = x2 - x1;

    return Math.abs((Math.atan2(dY, dX) / Math.PI) * 180.0);
  }
}
