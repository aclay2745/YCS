import { Injectable } from '@angular/core';
import { DrawingModel, IconImageModel, IconImageStoreModel } from './models';
import { Platform } from '@ionic/angular';
import { BehaviorSubject, Observable, of } from 'rxjs';
import * as _ from 'lodash';

@Injectable({ providedIn: 'root' })
export class DataStorageService {
  images = new BehaviorSubject([]);
  products = new BehaviorSubject([]);

  // TODO: Implement total drawings count
  public totalStoredDrawings;
  public currentDrawingImages: Observable<IconImageStoreModel> = of();
  public isPlatformReady: Observable<boolean> = of(false);
  public companyInfoStore: Observable<CompanyInfo> = of(new CompanyInfo());

  private imageStore = new Array<IconImageStoreModel>();
  private drawingStore = {};

  constructor(private platform: Platform) {
    if (this.platform.platforms().includes('cordova', 0)) {
      this.platform.ready().then(() => {
        this.isPlatformReady = of(true);
      });
    }
    this.fetchCompanyInfo();
  }

  /*
    Pass in the currently opened document id and initialize the image and document store
     */
  initializeStores(drawing: DrawingModel) {
    this.drawingStore = drawing;
    this.setCurrentId(drawing.drawingId);
    window['ldb'].set(drawing.drawingId, this.imageStore, 'i');
    window['ldb'].set(drawing.drawingId, this.drawingStore, 'd');
  }

  setCurrentId(id) {
    window['ldb'].set('id', id, 'c');
  }

  addImageToStore(toStore: IconImageModel, callback?) {
    window['ldb'].get(
      toStore.drawingId,
      (store) => {
        // look for an existing image for this icon
        const previous = this.findImage(store, toStore);

        if (previous) {
          // found one , remove it so we don't end up with multiples for the same icon.
          store = this.removeImage(store, previous);
        }

        store.push(toStore);
        this.saveStore(store, toStore.drawingId, 'i');

        if (callback) {
          callback();
        }
      },
      'i'
    );
  }

  getImageFromStore(drawingId: string, imageId: string) {
    window['ldb'].get(
      drawingId,
      (store) => {
        _.find(store, (image: IconImageModel) => image.imageId === imageId);
      },
      'i'
    );
  }

  getAllImagesForDrawing(callback) {
    window['ldb'].get(
      'id',
      (currentId) => {
        window['ldb'].get(
          currentId,
          (store: IconImageStoreModel) => {
            callback(store);
          },
          'i'
        );
      },
      'c'
    );
  }

  saveDrawing(id, drawing: DrawingModel, callback?) {
    window['ldb'].set(id, drawing, 'd');

    if (callback) {
      callback(drawing);
    }
  }

  getAllDrawings(callback) {
    window['ldb'].getAllDrawings(callback);
  }

  getDrawingCount(callback) {
    window['ldb'].getDrawingCount(callback);
  }

  getDrawingById(drawingId, callback?) {
    window['ldb'].get(
      drawingId,
      (drawing: DrawingModel) => {
        if (callback) {
          callback(drawing);
        }
      },
      'd'
    );
  }

  deleteDrawing(drawingId: string, callback) {
    window['ldb'].deleteDrawing(drawingId, callback);
  }

  saveCompanyInfo(info: CompanyInfo, callback?) {
    window['ldb'].set('Company', info, 'c');

    this.companyInfoStore = of(info);

    if (callback) {
      callback(info);
    }
  }

  saveUserInfo(info, callback?) {
    window['ldb'].set('User', info, 'u');

    if (callback) {
      callback(info);
    }
  }

  getUserInfo(callback) {
    window['ldb'].get('User', (info) => { callback(info); }, 'u');
  }

  fetchCompanyInfo(): void {
    const ci: CompanyInfo = new CompanyInfo();

    this.getCompanyInfo((info: CompanyInfo) => {
      if (!_.isEmpty(info)) {
        ci.phone = info.phone;
        ci.company = info.company;
        ci.address = info.address;
        ci.addressTwo = info.addressTwo;
        ci.city = info.city;
        ci.state = info.state;
        ci.zip = info.zip;
      }
    });

    this.companyInfoStore = of(ci);
  }

  private saveStore(store, drawingId: string, mode) {
    window['ldb'].set(drawingId, store, mode);
  }

  private findImage(store: IconImageStoreModel, toStore: IconImageModel) {
    return _.find(
      store,
      (image: IconImageModel) => image.imageId === toStore.imageId
    );
  }

  private removeImage(store: IconImageStoreModel, image: IconImageModel) {
    return _.pull(store, image);
  }

  private getCompanyInfo(callback?) {
    window['ldb'].get(
      'Company',
      (info: CompanyInfo) => {
        if (callback) {
          callback(info);
        }
      },
      'c'
    );
  }
}

export class CompanyInfo {
  phone;
  company;
  address;
  addressTwo;
  city;
  state;
  zip;

  constructor() {}
}
