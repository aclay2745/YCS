import * as SVG from 'svg.js';
import { IconEnums } from '../components/sketch/enums';
import { BehaviorSubject } from 'rxjs';
import { CameraService } from '../services/camera/camera.service';
import IssueIcon = IconEnums.DamageIcon;
import StructureIcon = IconEnums.StructureIcon;
import EquipmentIcon = IconEnums.EquipmentIcon;
import EnvironmentIcon = IconEnums.EnvironmentIcon;
import { EstimateService } from '../services/estimate/estimate.service';

export interface IconsAndPlots {
  iconRoot: string;
  plotsRoot: string;
}

export interface SketchStateModel {
  activatedPointIndex: number;
  lineArray: Array<StoredSketchLine>; // Array<SketchLine>
  previewLine: SVG.Line; // SVG.Line
  previewLineStartPoint: SVG.Circle;
  previewLineEndPoint: SVG.Circle;
  startTargetX: number;
  startTargetY: number;
  startTargetBounds: number;
  startElement: HTMLElement;
  lineOpts: {
    stroke: string;
    'stroke-width': number;
  };
  rectOpts: {
    height: number;
    width: number;
    stroke: string;
    'stroke-width': number;
    'stroke-opacity': number;
    fill: string;
    'fill-opacity': number;
  };
  gridOpts: {
    grid: number;
    unitScale: number;
    rootWidth: number;
    rootHeight: number;
  };
  pointOpts: {
    stroke: string;
    'stroke-opacity': number;
    'stroke-width': number;
    fill: string;
    'fill-opacity': number;
    size: number;
  };
}

export interface StoredSketchLine {
  line: SVG.Line;
  points: Array<SVG.Circle>;
  substratePath: SVG.Path;
  isComputationalSub: boolean;
  substratePattern: string;
}

export interface SerialSketchLines {
  linesAndPoints: SerialLineAndPoints;
}

export interface SerialLineAndPoints {
  line: string;
  points: Array<string>;
  substratePath: string;
  substratePattern: string;
  isComputationalSub: string;
}

export interface IconImageModel {
  id?: number;
  imageId: string;
  drawingId: string;
  data?: string;
  iconType: string;
  iconName: string;
  notes: string;
}

export interface IconImageStoreModel {
  id: string;
  images: Array<IconImageModel>;
}

export interface IconEventModel {
  event: any;
  markerIconSubject: BehaviorSubject<
    IssueIcon | StructureIcon | EquipmentIcon | EnvironmentIcon
  >;
  markerIconTypeSubject: BehaviorSubject<string>;
  cameraService: CameraService;
  forStorage: IconImageModel;
  estimateService?: EstimateService;
}

export interface DrawingModel {
  drawingId: string;
  svgDocument: IconsAndPlots;
  lastModified: Date;
  display: string;
  lineArray: Array<any>;
  //printAreaRect: PrintAreaRect;
}

export interface PrintAreaRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface IndexDBDrawingResult {
  k: string;
  v: DrawingModel;
}
