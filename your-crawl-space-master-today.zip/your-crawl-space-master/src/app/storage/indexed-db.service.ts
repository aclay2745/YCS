import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class IndexedDbService {
  // Doesn't work yet - Still using the old version that attaches to window
  indexedDB = window.indexedDB;
  db;
  request: IDBOpenDBRequest;
  dbName = 'YCS_SKETCH';
  version = 2;
  keyValue = {
    k: '',
    v: '',
  };
  get;
  set;
  dbReadyBehaviorSubject: BehaviorSubject<boolean> =
    new BehaviorSubject<boolean>(false);

  constructor() {
    if (!indexedDB) {
      alert('IndexDB is not supported on this device.');
      throw new Error();
    }

    this.request = indexedDB.open(this.dbName, this.version);

    this.request.onsuccess = this.onsuccess;
    this.request.onerror = this.onerror;
    this.request.onupgradeneeded = this.onupgradeneeded;
    this.get = this.getValue;
    this.set = this.setValue;
  }

  getValue(key, callback, store) {
    if (store === 'd') {
      this.db
        .transaction('DRAWINGS')
        .objectStore('DRAWINGS')
        .get(key).onsuccess = (event) => {
        const result = event.target.result.v;
        callback(result);
      };
    } else if (store === 'i') {
      this.db.transaction('IMAGES').objectStore('IMAGES').get(key).onsuccess = (
        event
      ) => {
        const result = event.target.result.v;
        callback(result);
      };
    } else {
      this.db
        .transaction('CURRENTID')
        .objectStore('CURRENTID')
        .get(key).onsuccess = (event) => {
        const result = event.target.result.v;
        callback(result);
      };
    }
  }

  getAllDrawings(callback) {
    if (!this.db) {
      setTimeout(() => {
        this.getAllDrawings(() => {
          console.log('shit');
        });
      }, 100);
      return;
    }

    this.db.transaction('DRAWINGS').objectStore('DRAWINGS').getAll().onsuccess =
      (event) => {
        const result = event.target.result;
        callback(result);
      };
  }

  deleteDrawing(id, callback) {
    const that = this;
    this.db
      .transaction('DRAWINGS', 'readwrite')
      .objectStore('DRAWINGS')
      .delete(id).onsuccess = () => {
        that.db
          .transaction('IMAGES', 'readwrite')
          .objectStore('IMAGES')
          .delete(id).onsuccess = () => callback();
      };
  }

  setValue(key, value, store) {
    // no callback for set needed because every next transaction will be anyway executed after this one
    this.keyValue.k = key;
    this.keyValue.v = value;
    if (store === 'd') {
      this.db
        .transaction('DRAWINGS', 'readwrite')
        .objectStore('DRAWINGS')
        .put(this.keyValue);
    } else if (store === 'i') {
      this.db
        .transaction('IMAGES', 'readwrite')
        .objectStore('IMAGES')
        .put(this.keyValue);
    } else {
      this.db
        .transaction('CURRENTID', 'readwrite')
        .objectStore('CURRENTID')
        .put(this.keyValue);
    }
  }

  private onsuccess(event) {
    this.db = event.result;
    this.dbReadyBehaviorSubject.next(true);
  }

  private onerror(event) {
    console.error('indexedDB request error');
    console.log(event);
  }

  private onupgradeneeded(event) {
    this.db = null;
    const store = event.target.result.createObjectStore('DRAWINGS', {
      keyPath: 'k',
    });

    const imgStore = event.target.result.createObjectStore('IMAGES', {
      keyPath: 'k',
    });

    const currentDrawingIdStore = event.target.result.createObjectStore(
      'CURRENTID',
      {
        keyPath: 'k',
      }
    );

    const companyInfoStore = event.target.result.createObjectStore(
      'COMPANYINFO',
      {
        keyPath: 'k',
      }
    );

    companyInfoStore.transaction.oncomplete = (e) => {
      this.db = e.target.db;
    };
  }
}
