import { Injectable } from '@angular/core';
import { SketchService } from '../../components/sketch/sketch.service';
import { StoredSketchLine } from '../../storage/models';
import * as SVG from 'svg.js';
import { SketchComponentUtil } from '../../components/sketch/lib/sketch.component.util';
import * as _ from 'lodash';
import {
  PolyPointCoord,
  PolyPointLineCoords,
} from '../../components/sketch/models';
import { BehaviorSubject, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EstimateService {
  public sqftTotal = new BehaviorSubject<number>(0);
  public tempCalc = new BehaviorSubject<number>(0);
  public pierCount816 = new BehaviorSubject<number>(0);
  public pierCount1616 = new BehaviorSubject<number>(0);
  public productModel: Products;
  public isEstimateActive = new BehaviorSubject<boolean>(false);
  public estimatePolygon;

  private groupTopLeft;
  private pierLinealfootage = 4;

  constructor(private sketchService: SketchService) {
    this.productModel = new Products();

    this.sketchService.undo.subscribe(() => {
      this.estimate();
    });

    this.sketchService.redo.subscribe(() => {
      this.estimate();
    });
  }

  calculateAll() {
    this.tempCalc.next(0);
    const keys = Object.keys(this.productModel);
    for (let i = 0; i < keys.length; i++) {
      this.productModel[keys[i]].amountNeeded.next(
        this.calculateProductRequired(this.productModel[keys[i]])
      );
    }
    // console.log(this.productModel);
  }

  calculateProductRequired(product: ProductSpec) {
    if (!product.lineal) {
      if (this.tempCalc.value < this.sqftTotal.value) {
        this.tempCalc.next(this.tempCalc.value + product.coverage);
        this.calculateProductRequired(product);
      }

      return Math.ceil(this.tempCalc.value / product.coverage);
    }

    return Math.ceil(
      this.sketchService.getPerimeter().value / product.coverage
    );
  }

  estimate() {
    this.isEstimateActive.next(false);
    // estimate the piers
    const pierTotal = this.pierCount1616.getValue() * this.pierLinealfootage;

    _.each(
      SketchComponentUtil.getAllEstimatePolygons(),
      (poly: SVG.Element) => {
        poly.remove();
      }
    );

    const lines: Array<StoredSketchLine> = this.getStoredLines();
    let unorderedCoords: Array<PolyPointLineCoords> = [];

    const xPoints = [];
    const yPoints = [];

    /*  const group = SVG('plots').group();
        const box = group.bbox();*/

    lines.forEach((line) => {
      if (line.isComputationalSub) {
        xPoints.push(line.points[0].attr('cx'));
        yPoints.push(line.points[0].attr('cy'));

        const coord0 = {
          x: line.points[0].attr('cx'),
          y: line.points[0].attr('cy'),
        };
        const coord1 = {
          x: line.points[1].attr('cx'),
          y: line.points[1].attr('cy'),
        };

        unorderedCoords.push({ start: coord0, end: coord1 });
      }
    });

    /* // get the center of the group
        const center = this.getBboxTopLeft(group);
        this.groupTopLeft = SketchComponentUtil.domCoordsToSvgCoords(center.x, center.y);*/

    unorderedCoords = _.uniqWith(unorderedCoords, _.isEqual);

    let stringCoords = '';

    const orderedCoords: Array<PolyPointLineCoords> = [];

    unorderedCoords.forEach((c: PolyPointLineCoords) => {
      stringCoords +=
        c.start.x +
        ',' +
        c.start.y +
        String(' ') +
        c.end.x +
        ',' +
        c.end.y +
        String(' ');
    });

    if (unorderedCoords.length >= 3) {
      this.isEstimateActive.next(true);
      const polygon = SVG('plots').polygon(stringCoords);
      polygon.fill('#d1f2ff').opacity(1);
      polygon.back();
      polygon.attr('class', 'estimate-polygon');

      const area = this.polygonArea(xPoints, yPoints, xPoints.length);
      this.sketchService.setSqft(area);
      this.sqftTotal.next(area);

      this.sketchService.setPerimeter(pierTotal + this.calculatePerimeter());

      this.estimatePolygon = polygon;
    }

    // SVG('plots').ungroup(group);
  }

  polygonArea(x, y, numPoints) {
    let area = 0; // Accumulates area in the loop
    let j = numPoints - 1; // The last vertex is the 'previous' one to the first

    for (let i = 0; i < numPoints; i++) {
      area = area + (x[j] + x[i]) * (y[j] - y[i]);
      j = i;
    }
    return Math.ceil(Math.abs(area / 2) / 144);
  }

  sqftFromCoords(coordArray) {
    const x = coordArray.reverse();
    let a = 0;
    if (x.length % 2) {
      return;
    }
    for (let i = 0, iLen = x.length - 2; i < iLen; i += 2) {
      a += x[i] * x[i + 3] - x[i + 2] * x[i + 1];
    }
    return Math.abs(a / 2) / 288;
  }

  getBboxTopLeft(group: SVG.G) {
    const bbox = group.bbox();
    const ctm = group.ctm();
    const cx = bbox.x + bbox.width / 2;
    const cy = bbox.y + bbox.height / 2;
    const pt = SVG('plots').point();
    pt.x = cx;
    pt.y = cy;

    return pt.transform(ctm);
  }

  pointSort(pointA: PolyPointCoord, pointB: PolyPointCoord) {
    const center = this.groupTopLeft;

    if (pointA.x - center.x >= 0 && pointB.x - center.x < 0) {
      return true;
    }

    if (pointA.x - center.x < 0 && pointB.x - center.x >= 0) {
      return false;
    }

    if (pointA.x - center.x === 0 && pointB.x - center.x === 0) {
      if (pointA.y - center.y >= 0 || pointB.y - center.y >= 0) {
        return pointA.y > pointB.y;
      }
      return pointB.y > pointA.y;
    }

    const det =
      (pointA.x - center.x) * (pointB.y - center.y) -
      (pointB.x - center.x) * (pointA.y - center.y);
    if (det < 0) {
      return true;
    }

    if (det > 0) {
      return false;
    }

    const d1 =
      (pointA.x - center.x) * (pointA.x - center.x) +
      (pointA.y - center.y) * (pointA.y - center.y);

    const d2 =
      (pointB.x - center.x) * (pointB.x - center.x) +
      (pointB.y - center.y) * (pointB.y - center.y);

    return d1 > d2;
  }

  // get the total perimeter of the space
  calculatePerimeter() {
    const lines = this.getStoredLines();

    let total = 0;
    if (lines && lines.length > 0) {
      lines.forEach((l) => {
        if (l.isComputationalSub) {
          total += Math.round(SketchComponentUtil.distance(l.line)) / 12;
        }
      });
      return Number(Math.ceil(total));
    }
  }

  private getStoredLines(): Array<StoredSketchLine> {
    const sketchComp = this.sketchService.sketchComponentInstance;
    return sketchComp.sketchState.lineArray;
  }

  private compare(obj1, obj2) {
    // Loop through properties in object 1
    // tslint:disable-next-line:forin
    for (const p in obj1) {
      // Check property exists on both objects
      if (obj1.hasOwnProperty(p) !== obj2.hasOwnProperty(p)) {
        return false;
      }

      switch (typeof obj1[p]) {
        // Deep compare objects
        case 'object':
          if (!this.compare(obj1[p], obj2[p])) {
            return false;
          }
          break;
        // Compare function code
        case 'function':
          if (
            typeof obj2[p] === 'undefined' ||
            (p !== 'compare' && obj1[p].toString() !== obj2[p].toString())
          ) {
            return false;
          }
          break;
        // Compare values
        default:
          if (obj1[p] !== obj2[p]) {
            return false;
          }
      }
    }

    // Check object 2 for any extra properties
    for (const p in obj2) {
      if (typeof obj1[p] === 'undefined') {
        return false;
      }
    }
    return true;
  }
}

export class Products {
  CrawlCurtain_2ft: ProductSpec = {
    id: 0,
    coverage: 100,
    display: 'Crawl Curtain 2ft',
    pdf: '01.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };

  CrawlCurtain_3ft: ProductSpec = {
    id: 1,
    coverage: 100,
    display: 'Crawl Curtain 3ft',
    pdf: '01.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };
  CrawlCurtain_4ft: ProductSpec = {
    id: 2,
    coverage: 100,
    display: 'Crawl Curtain 4ft',
    pdf: '01.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };

  CrawlCurtain_6ft: ProductSpec = {
    id: 3,
    coverage: 100,
    display: 'Crawl Curtain 6ft',
    pdf: '01.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };

  VaporBarrierFull_36mm: ProductSpec = {
    id: 4,
    coverage: 790,
    display: 'Premium 36mm Ground Vapor Barrier',
    pdf: '02.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: false,
  };

  VaporBarrierFull_15mm: ProductSpec = {
    id: 5,
    coverage: 1200,
    display: '100% Reinforced 15 mil Vapor Barrier - Full Roll',
    pdf: '03.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: false,
  };
  VaporBarrierHalf_15mm: ProductSpec = {
    id: 6,
    coverage: 600,
    display: '100% Reinforced 15 mil Vapor Barrier - Half Roll',
    pdf: '03.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: false,
  };

  VaporBarrierFull_9mm: ProductSpec = {
    id: 7,
    coverage: 1250,
    display: '100% Reinforced 9 mil Vapor Barrier',
    pdf: '04.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: false,
  };

  VaporBarrierPrecut_2_9mm: ProductSpec = {
    id: 8,
    coverage: 100,
    display: '100% Reinforced 9 mil Vapor Barrier - Precut 2ft x 100ft',
    pdf: '04.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };

  VaporBarrierPrecut_3_9mm: ProductSpec = {
    id: 9,
    coverage: 100,
    display: '100% Reinforced 9 mil Vapor Barrier - Precut 3ft x 100ft',
    pdf: '04.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };

  VaporBarrierPrecut_4_9mm: ProductSpec = {
    id: 10,
    coverage: 100,
    display: '100% Reinforced 9 mil Vapor Barrier - Precut 4ft x 100ft',
    pdf: '04.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };

  VaporBarrierPrecut_6_9mm: ProductSpec = {
    id: 11,
    coverage: 100,
    display: '100% Reinforced 9 mil Vapor Barrier - Precut 6ft x 100ft',
    pdf: '04.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };

  MagicSealantAdhesive: ProductSpec = {
    id: 12,
    coverage: 50,
    display: 'Magic Sealant / Adhesive',
    pdf: '05.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };

  SeamTape: ProductSpec = {
    id: 13,
    coverage: 250,
    display: 'Seam Tape',
    pdf: '06.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: false,
  };

  WallAttachmentTape: ProductSpec = {
    id: 14,
    coverage: 100,
    display: 'Wall Attachment Tape',
    pdf: '07.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };
  SeamWeld: ProductSpec = {
    id: 15,
    coverage: 334,
    display: 'Seam Weld',
    pdf: '08.pdf',
    amountNeeded: new BehaviorSubject<number>(0),
    lineal: true,
  };
}

export interface ProductSpec {
  id: number;
  coverage: number;
  display: string;
  pdf: string;
  amountNeeded: BehaviorSubject<number>;
  lineal: boolean;
}
