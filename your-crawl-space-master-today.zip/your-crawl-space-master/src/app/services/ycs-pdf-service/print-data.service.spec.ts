import { TestBed } from '@angular/core/testing';

import { PrintAreaHighlightService } from './print-area-highlight.service';

describe('PrintDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PrintAreaHighlightService = TestBed.get(PrintAreaHighlightService);
    expect(service).toBeTruthy();
  });
});
