import { TestBed } from '@angular/core/testing';

import { YcsPdfService } from './ycs-pdf.service';

describe('YcsPdfService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: YcsPdfService = TestBed.get(YcsPdfService);
    expect(service).toBeTruthy();
  });
});
