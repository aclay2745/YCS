import { Injectable } from '@angular/core';
import * as SVG from 'svg.js';
import { SketchService } from '../../components/sketch/sketch.service';

@Injectable({
  providedIn: 'root',
})
export class PrintAreaHighlightService {
  public rect: SVG.Rect;
  public defaultHeight = 800;
  public defaultWidth = 1100;
  public defaultViewBox;

  private initialCoords;
  private currentCoords;
  private width = this.defaultWidth;
  private height = this.defaultHeight;
  private x = 0;
  private y = 0;

  constructor(private _sketchService: SketchService) {}

  public get getWidth() {
    return this.width;
  }

  public set setWidth(value: number) {
    this.width = value;
  }

  public get getHeight() {
    return this.height;
  }

  public set setHeight(value: number) {
    this.height = value;
  }

  public get getX() {
    return this.x;
  }

  public set setX(value: number) {
    this.x = value;
  }

  public get getY() {
    return this.y;
  }

  public set setY(value: number) {
    this.y = value;
  }

  updateRectangle() {
    this.rect = SVG.select('rect.print-rect')['members'][0];

    this.x = Math.min(this.initialCoords.x, this.currentCoords.x);
    this.y = Math.min(this.initialCoords.y, this.currentCoords.y);

    this.width = Math.abs(this.currentCoords.x - this.initialCoords.x);
    this.height = Math.abs(this.currentCoords.y - this.initialCoords.y);

    this.rect.attr('x', String(this.x));
    this.rect.attr('y', String(this.y));
    this.rect.attr('width', String(this.width));
    this.rect.attr('height', String(this.height));
  }

  printAreaMouseDown(e) {
    const that = this;
    (SVG.select('rect.print-rect')['members'][0] as SVG.Rect).attr(
      'display',
      'block'
    );
    const domToSVG = (event) => {
      const plots = SVG('print-area-selection'); // PLay here

      const p = new SVG.Point();

      if (event.touches !== undefined) {
        console.log(event.touches);
        p.x = (event.touches as TouchList)[0].clientX;
        p.y = (event.touches as TouchList)[0].clientY;
      } else {
        p.x = event.x;
        p.y = event.y;
      }

      return p.transform(plots.screenCTM().inverse());
    };

    this.initialCoords = domToSVG(e);

    const printAreaMouseMove = (ev) => {
      that.currentCoords = domToSVG(ev);
      that.updateRectangle();
    };

    const printAreaMouseup = (ev) => {
      document.removeEventListener('mousemove', printAreaMouseMove);
      document.removeEventListener('mouseup', printAreaMouseup);
      document.removeEventListener('touchmove', printAreaMouseMove);
      document.removeEventListener('touchend', printAreaMouseup);
      SVG.select('svg.plots')['members'][0].viewbox(
        that.x,
        that.y,
        that.width,
        that.height
      );
      SVG.select('svg.icons')['members'][0].viewbox(
        that.x,
        that.y,
        that.width,
        that.height
      );
      (SVG.select('rect.print-rect')['members'][0] as SVG.Rect).attr(
        'display',
        'none'
      );
    };

    document.addEventListener('mousemove', printAreaMouseMove);
    document.addEventListener('mouseup', printAreaMouseup);
    document.addEventListener('touchmove', printAreaMouseMove);
    document.addEventListener('touchend', printAreaMouseup);
  }
}
