import { TestBed } from '@angular/core/testing';

import { IconSvgService } from './icon-svg.service';

describe('IconSvgService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IconSvgService = TestBed.get(IconSvgService);
    expect(service).toBeTruthy();
  });
});
