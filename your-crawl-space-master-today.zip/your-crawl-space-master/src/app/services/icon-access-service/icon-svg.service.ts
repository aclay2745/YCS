import { Injectable } from '@angular/core';
import {
  DamageActiveFungus,
  DamageActiveTermites,
  DamageInactiveFungus,
  DamageInactiveTermites,
  DamageMold,
  DamageRodent,
  DamageStandingWater,
  DamageWater,
  IconFrame,
  IconFrameHalf,
  IconFrameTransparent,
  StandardPier,
} from './icon-classes-damage';
import {
  EquipmentDehumidifier,
  EquipmentHVAC,
  EquipmentServiceMonitor,
  EquipmentSumpPump,
  EquipmentWaterHeater,
} from './icon-classes-equipment';
import {
  StructureAccessDoor,
  StructureDog,
  StructureDrain,
  StructureFenceGate,
  StructureGradeArrow,
  StructureVent,
} from './icon-classes-structure';

@Injectable({
  providedIn: 'root',
})
export class IconSvgService {
  constructor() {}

  getIconSVG(icon: string) {
    const isDamage = icon.search('DMG_') === 0;
    const isEnvironment = icon.search('ENV_') === 0;
    const isEquipment = icon.search('EQP_') === 0;
    const isStructure = icon.search('STR_') === 0;

    if (isDamage) {
      return this.getDamageIcon(icon);
    }

    if (isEquipment) {
      return this.getEquipmentIcon(icon);
    }

    if (isStructure || isEnvironment) {
      return this.getStructureIcon(icon);
    }
  }

  getDamageIcon(icon: string) {
    switch (icon) {
      case 'DMG_WATER':
        return DamageWater.svg;
      case 'DMG_STANDING_WATER':
        return DamageStandingWater.svg;
      case 'DMG_RODENT':
        return DamageRodent.svg;
      case 'DMG_TERMITE_ACTIVE':
        return DamageActiveTermites.svg;
      case 'DMG_TERMITE_INACTIVE':
        return DamageInactiveTermites.svg;
      case 'DMG_MOLD':
        return DamageMold.svg;
      case 'DMG_FUNGUS_ACTIVE':
        return DamageActiveFungus.svg;
      case 'DMG_FUNGUS_INACTIVE':
        return DamageInactiveFungus.svg;
    }
  }

  getEquipmentIcon(icon: string) {
    switch (icon) {
      case 'EQP_HVAC':
        return EquipmentHVAC.svg;
      case 'EQP_DEHUMIDIFIER':
        return EquipmentDehumidifier.svg;
      case 'EQP_SERVICE_MONITOR':
        return EquipmentServiceMonitor.svg;
      case 'EQP_SUMP_PUMP':
        return EquipmentSumpPump.svg;
      case 'EQP_WATER_HEATER':
        return EquipmentWaterHeater.svg;
    }
  }

  getStructureIcon(icon: string) {
    switch (icon) {
      case 'STR_VENT_HALF':
        return StructureVent.svg;
      case 'ENV_DOG':
        return StructureDog.svg;
      case 'ENV_GRADE_ARROW':
        return StructureGradeArrow.svg;
      case 'STR_ACCESS_DOOR':
        return StructureAccessDoor.svg;
      case 'STR_DRAIN':
        return StructureDrain.svg;
      case 'STR_FENCE_GATE':
        return StructureFenceGate.svg;
      case 'STR_PIER_16_16':
        return StandardPier.svg;
    }
  }

  getIconFrame() {
    return IconFrame.svg;
  }

  getIconFrameTransparent() {
    return IconFrameTransparent.svg;
  }

  getIconFrameHalf() {
    return IconFrameHalf.svg;
  }
}
