import { Injectable } from '@angular/core';
import { Camera, CameraResultType, ImageOptions, CameraSource, CameraPluginPermissions } from '@capacitor/camera';
import { BehaviorSubject, of } from 'rxjs';
import { IconImageModel } from '../../storage/models';
import { DataStorageService } from '../../storage/data-storage.service';
import { ToastController } from '@ionic/angular';

@Injectable()
export class CameraService {
  options: ImageOptions = {
    quality: 85,
    resultType: CameraResultType.DataUrl,
    source: CameraSource.Camera,
    saveToGallery: true,
    allowEditing: true
  };

  cameraActive: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  currentImage;
  imageStack: Array<IconImageModel> = new Array<IconImageModel>();
  imageStackObs = of(this.imageStack);

  constructor(
    private storage: DataStorageService,
    public toastController: ToastController
  ) {}

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'Your image has been saved.',
      duration: 2000,
      position: 'middle',
    });
    toast.present();
  }

  async takePicture(forStorage: IconImageModel) {
    if (this.permissionsGranted()) {
      try {
        const imageData = await Camera.getPhoto(this.options);

        this.currentImage = imageData.dataUrl;

        forStorage.data = imageData.dataUrl;

        this.imageStack.push(forStorage);

        this.storage.addImageToStore(forStorage, () => {
          const toastResult = this.presentToast();
        });
      } catch (err) {
        if (!err.message.includes('cancelled')) {
          console.error(err);
          alert('There was an error storing the image');
        }
      }
    }
  }

  async permissionsGranted() {
    let granted = false;
    const result = await Camera.checkPermissions();
    if (result.camera === 'denied' || result.photos === 'denied') {
      const permissions: CameraPluginPermissions = { permissions: ['camera', 'photos'] };
      const requestResult = await Camera.requestPermissions(permissions);

      if ((requestResult.photos === 'granted' || requestResult.camera === 'granted') &&
          (requestResult.photos === 'limited' || requestResult.camera === 'limited')) {
        granted = true;
      }
    } else {
      granted = true;
    }

    return granted;
  }
}
