(function () {
  const indexedDB =
    window.indexedDB ||
    window.mozIndexedDB ||
    window.webkitIndexedDB ||
    window.msIndexedDB;

  if (!indexedDB) {
    console.error('indexDB not supported');
    return;
  }

  let db,
    keyValue = {
      k: '',
      v: ''
    },
    request = indexedDB.open('YCS_SKETCH', 1);
  request.onsuccess = function (evt) {
    db = this.result;
  };

  request.onerror = function (event) {
    console.error('indexedDB request error');
    console.log(event);
  };

  request.onupgradeneeded = function (event) {
    db = null;
    const store = event.target.result.createObjectStore('DRAWINGS', {
      keyPath: 'k'
    });

    const imgStore = event.target.result.createObjectStore('IMAGES', {
      keyPath: 'k'
    });

    const currentDrawingIdStore = event.target.result.createObjectStore('CURRENTID', {
      keyPath: 'k'
    });

    const companyInfoStore = event.target.result.createObjectStore('COMPANYINFO', {
      keyPath: 'k'
    });

    companyInfoStore.transaction.oncomplete = function (e) {
      db = e.target.db;
    };
  };

  function getValue(key, callback, store) {
    if (!db) {
      setTimeout(function () {
        getValue(key, callback);
      }, 100);
      return;
    }

    if (store === 'd') {
      db.transaction('DRAWINGS').objectStore('DRAWINGS').get(key).onsuccess = function (event) {
        const result = event.target.result;
        if (!result) {
          callback([]);
        } else {
          callback(result.v);
        }
      };
    } else if (store === 'i') {
      db.transaction('IMAGES').objectStore('IMAGES').get(key).onsuccess = function (event) {
        const result = event.target.result;
        if (!result) {
          callback([]);
        } else {
          callback(result.v);
        }
      };
    } else if (store === 'c') {
      db.transaction('COMPANYINFO').objectStore('COMPANYINFO').get(key).onsuccess = function (event) {
        const result = event.target.result;
        if (!result) {
          callback({});
        }

        callback(result.v);
      };
    } else if (store === 'u') {
      db.transaction('USERINFO').objectStore('USERINFO').get(key).onsuccess = function (event) {
        const result = event.target.result;
        if (!result) {
          callback({});
        } else {
          callback(result.v);
        }
      }
    } else {
      db.transaction('CURRENTID').objectStore('CURRENTID').get(key).onsuccess = function (event) {
        const result = event.target.result.v;
        callback(result);
      };
    }
  }

  function getAllDrawings(callback) {
    if (!db) {
      setTimeout(function () {
        getAllDrawings(callback);
      }, 100);
      return;
    }

    db.transaction('DRAWINGS').objectStore('DRAWINGS').getAll().onsuccess = function (event) {
      const result = event.target.result;
      callback(result);
    }
  }

  function getDrawingCount(callback) {
    if (!db) {
      setTimeout(function () {
        getDrawingCount(callback);
      }, 100);
      return;
    }

    db.transaction('DRAWINGS').objectStore('DRAWINGS').getAll().onsuccess = function (event) {
      const result = event.target.result;
      callback(result.length);
    }
  }

  function deleteDrawing(id, callback) {
    db.transaction('DRAWINGS', 'readwrite').objectStore('DRAWINGS').delete(id).onsuccess = function () {
      db.transaction('IMAGES', 'readwrite').objectStore('IMAGES').delete(id).onsuccess = function () {
        callback();
      };
    };
  }

  window['ldb'] = {
    deleteDrawing: deleteDrawing,
    getAllDrawings: getAllDrawings,
    getDrawingCount: getDrawingCount,
    get: getValue,
    set: function (key, value, store) {
      // no callback for set needed because every next transaction will be anyway executed after this one
      keyValue.k = key;
      keyValue.v = value;
      if (store === 'd') {
        db.transaction('DRAWINGS', 'readwrite').objectStore('DRAWINGS').put(keyValue);
      } else if (store === 'i') {
        db.transaction('IMAGES', 'readwrite').objectStore('IMAGES').put(keyValue);
      } else if (store === 'c') {
        db.transaction('COMPANYINFO', 'readwrite').objectStore('COMPANYINFO').put(keyValue);
      } else if (store === 'u') {
        db.transaction('USERINFO', 'readwrite').objectStore('USERINFO').put(keyValue);
      } else {
        db.transaction('CURRENTID', 'readwrite').objectStore('CURRENTID').put(keyValue);
      }
    }
  }

})();
