import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.yourcrawlspace.app',
  appName: 'Your Crawl Space',
  webDir: 'www',
  plugins: {},
};

export default config;
